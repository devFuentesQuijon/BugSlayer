# Bug Fixing Patterns

Snippets de código "antes/después" para los bugs más comunes encontrados
en auditorías. Usar como referencia rápida durante la fase de exterminación.

---

## Python

### Patrón: print() → logger

**Antes:**
```python
def process_data(data):
    print(f"Processing {len(data)} items")
    try:
        result = heavy_computation(data)
        print(f"Result: {result}")
    except Exception as e:
        print(f"Error: {e}")
    return result
```

**Después:**
```python
import logging

logger = logging.getLogger(__name__)

def process_data(data):
    logger.info(f"Processing {len(data)} items")
    try:
        result = heavy_computation(data)
        logger.info(f"Result: {result}")
    except Exception as e:
        logger.error(f"Error processing data: {e}", exc_info=True)
        raise
    return result
```

---

### Patrón: except: pass → logging + re-raise

**Antes:**
```python
def fetch_data(url):
    try:
        response = requests.get(url)
        return response.json()
    except:
        pass
```

**Después:**
```python
def fetch_data(url):
    try:
        response = requests.get(url, timeout=10)
        response.raise_for_status()
        return response.json()
    except requests.RequestException as e:
        logger.error(f"Failed to fetch {url}: {e}")
        raise DataFetchError(f"Could not fetch data from {url}") from e
```

---

### Patrón: SQLite + WAL Mode

**Antes:**
```python
def init_db(db_path):
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()
    cursor.execute("CREATE TABLE IF NOT EXISTS users (id INTEGER PRIMARY KEY)")
    conn.commit()
    return conn
```

**Después:**
```python
def init_db(db_path):
    conn = sqlite3.connect(db_path)
    # WAL mode permite lecturas concurrentes
    conn.execute("PRAGMA journal_mode=WAL")
    conn.execute("PRAGMA synchronous=NORMAL")
    cursor = conn.cursor()
    cursor.execute("CREATE TABLE IF NOT EXISTS users (id INTEGER PRIMARY KEY)")
    conn.commit()
    return conn
```

---

### Patrón: Race Condition → Lock

**Antes:**
```python
_rag_engine = None
is_loading = False

def get_engine():
    global _rag_engine, is_loading
    if _rag_engine is None and not is_loading:
        is_loading = True
        _rag_engine = initialize_engine()  # Lento
        is_loading = False
    return _rag_engine
```

**Después:**
```python
import threading

_rag_engine = None
_rag_engine_lock = threading.Lock()

def get_engine():
    global _rag_engine
    if _rag_engine is not None:
        return _rag_engine
    
    with _rag_engine_lock:
        # Double-check después de adquirir lock
        if _rag_engine is not None:
            return _rag_engine
        _rag_engine = initialize_engine()
        return _rag_engine
```

---

### Patrón: Bucle Infinito → Backoff Exponencial

**Antes:**
```python
def run_bot():
    while True:
        try:
            bot.polling()
        except Exception as e:
            print(f"Error: {e}")
            time.sleep(30)
```

**Después:**
```python
def run_bot():
    max_retries = 5
    base_delay = 5
    
    for attempt in range(max_retries):
        try:
            bot.polling()
            break  # Éxito, salir
        except Exception as e:
            logger.error(f"Bot error (attempt {attempt + 1}/{max_retries}): {e}")
            if attempt == max_retries - 1:
                logger.critical("Max retries reached. Exiting.")
                raise
            delay = base_delay * (2 ** attempt)
            logger.info(f"Retrying in {delay}s...")
            time.sleep(delay)
```

---

### Patrón: Null Dereference → Guarda

**Antes:**
```python
def classify_text(self, text):
    prompt = f"Classify: {text}"
    result = self.llm.complete(prompt)  # self.llm puede ser None
    return result.strip()
```

**Después:**
```python
def classify_text(self, text):
    if not self.llm:
        logger.warning("LLM unavailable, using default classification")
        return "unknown"
    
    prompt = f"Classify: {text}"
    try:
        result = self.llm.complete(prompt)
        return result.strip() if result else "unknown"
    except Exception as e:
        logger.error(f"LLM classification failed: {e}")
        return "unknown"
```

---

### Patrón: Secretos Hardcodeados → Variables de Entorno

**Antes:**
```python
API_KEY = "sk-live-abc123xyz789"
DB_PASSWORD = "supersecret123"
```

**Después:**
```python
import os
from typing import Optional

API_KEY: str = os.environ.get("API_KEY", "")
DB_PASSWORD: str = os.environ.get("DB_PASSWORD", "")

def validate_config():
    if not API_KEY:
        raise ValueError("API_KEY environment variable is required")
    if not DB_PASSWORD:
        raise ValueError("DB_PASSWORD environment variable is required")
```

---

### Patrón: Cache Sin Límites → LRU Cache

**Antes:**
```python
_embedding_cache = {}

def get_embedding(text):
    if text not in _embedding_cache:
        _embedding_cache[text] = model.embed(text)
    return _embedding_cache[text]
```

**Después:**
```python
from functools import lru_cache

@lru_cache(maxsize=1000)
def get_embedding(text: str) -> list[float]:
    return model.embed(text)

# O para más control:
from cachetools import TTLCache

_embedding_cache = TTLCache(maxsize=1000, ttl=3600)

def get_embedding(text: str) -> list[float]:
    if text not in _embedding_cache:
        _embedding_cache[text] = model.embed(text)
    return _embedding_cache[text]
```

---

### Patrón: Write No Atómico → Atomic Write

**Antes:**
```python
def save_secrets(data):
    with open("secrets.json", "w") as f:
        json.dump(data, f)
```

**Después:**
```python
import os
import tempfile
import shutil

def save_secrets(data):
    # Backup previo
    backup_path = "secrets.json.bak"
    if os.path.exists("secrets.json"):
        shutil.copy2("secrets.json", backup_path)
    
    # Write atómico
    temp_fd, temp_path = tempfile.mkstemp(dir=".", suffix=".tmp")
    try:
        with os.fdopen(temp_fd, "w") as f:
            json.dump(data, f)
        os.replace(temp_path, "secrets.json")
    except Exception:
        # Restaurar backup si falla
        if os.path.exists(backup_path):
            shutil.copy2(backup_path, "secrets.json")
        raise
```

---

### Patrón: Request Sin Timeout → Timeout Explícito

**Antes:**
```python
response = requests.get(url)
```

**Después:**
```python
response = requests.get(url, timeout=(5, 30))  # (connect, read)
response.raise_for_status()
```

---

## JavaScript / TypeScript

### Patrón: innerHTML → textContent + DOMPurify

**Antes:**
```javascript
element.innerHTML = userInput;
```

**Después:**
```javascript
import DOMPurify from 'dompurify';

// Para texto plano (recomendado)
element.textContent = userInput;

// Si necesitas HTML (con sanitización)
element.innerHTML = DOMPurify.sanitize(userInput);
```

---

### Patrón: Async Sin Catch → Try/Catch

**Antes:**
```javascript
fetch('/api/data')
  .then(res => res.json())
  .then(data => setData(data));
```

**Después:**
```javascript
try {
  const res = await fetch('/api/data');
  if (!res.ok) throw new Error(`HTTP ${res.status}`);
  const data = await res.json();
  setData(data);
} catch (error) {
  logger.error('Failed to fetch data:', error);
  setError(error.message);
}
```

---

## Go

### Patrón: Goroutine Sin Wait → sync.WaitGroup

**Antes:**
```go
for _, url := range urls {
    go fetch(url)  // Fire and forget
}
```

**Después:**
```go
var wg sync.WaitGroup
for _, url := range urls {
    wg.Add(1)
    go func(u string) {
        defer wg.Done()
        fetch(u)
    }(url)
}
wg.Wait()  // Esperar a que todas terminen
```

---

### Patrón: Error Ignorado → Check Explícito

**Antes:**
```go
_ = db.Ping()  // Ignorando error
```

**Después:**
```go
if err := db.Ping(); err != nil {
    return fmt.Errorf("database ping failed: %w", err)
}
```

---

## Rust

### Patrón: unwrap() → Result Handling

**Antes:**
```rust
let data = fs::read_to_string("config.json").unwrap();
let config: Config = serde_json::from_str(&data).unwrap();
```

**Después:**
```rust
let data = fs::read_to_string("config.json")
    .map_err(|e| AppError::ConfigRead(e))?;
let config: Config = serde_json::from_str(&data)
    .map_err(|e| AppError::ConfigParse(e))?;
```

---

## Patrones Transversales (Todos los Lenguajes)

### Validación de Input

**Antes:**
```python
user_id = request.args["user_id"]
```

**Después:**
```python
from pydantic import BaseModel, validator

class UserRequest(BaseModel):
    user_id: int
    
    @validator('user_id')
    def validate_user_id(cls, v):
        if v <= 0:
            raise ValueError('user_id must be positive')
        return v

try:
    req = UserRequest(**request.json)
except ValidationError as e:
    return jsonify({"error": str(e)}), 400
```

---

### Rate Limiting

**Antes:**
```python
for user in users:
    send_email(user.email)  # Sin control de rate
```

**Después:**
```python
import time
from ratelimit import limits, sleep_and_retry

@sleep_and_retry
@limits(calls=10, period=60)
def send_email(email):
    # ... enviar email ...
    pass

for user in users:
    try:
        send_email(user.email)
    except RateLimitException:
        logger.warning(f"Rate limit hit for {user.email}")
    time.sleep(0.1)  # Throttle adicional
```

---

### Health Check Endpoint

**Antes:**
```python
@app.route("/health")
def health():
    return "OK"
```

**Después:**
```python
@app.route("/health")
def health():
    checks = {
        "database": check_db(),
        "cache": check_cache(),
        "external_api": check_external_api(),
    }
    
    all_healthy = all(checks.values())
    status = 200 if all_healthy else 503
    
    return jsonify({
        "status": "healthy" if all_healthy else "unhealthy",
        "checks": checks,
        "timestamp": datetime.now(timezone.utc).isoformat(),
    }), status
```
