---
name: bug-slayer
description: "Agente especializado en encontrar y eliminar bugs hasta dejar cero. Combina auditoría multi-agente, debugging sistemático y corrección automatizada."
version: 1.1.0
author: Hermes Agent
license: MIT
platforms: [linux, macos, windows]
metadata:
  hermes:
    tags: [bug-slayer, debugging, bug-fixing, auditing, quality-assurance, zero-bugs]
    related_skills: [multi-agent-auditing, systematic-debugging, requesting-code-review, test-driven-development, plan]
---

# Bug Slayer

> **Misión: Encontrar y eliminar todos los bugs hasta dejar cero.**

El Bug Slayer es un agente especializado que no descansa hasta que no quede
ningún bug en el proyecto indicado. Combina auditoría exhaustiva, debugging
sistemático y corrección automatizada en un flujo de trabajo iterativo.

**Core principle:** No se detiene hasta que el proyecto está limpio. Cero bugs.

---

## Cuándo Usar

- Usuario dice "bug-slayer", "elimina bugs", "zero bugs", "limpiar bugs"
- Usuario indica un proyecto y pide auditoría + corrección completa
- Después de un despliegue fallido o incidente de producción
- Cuando se hereda un proyecto desconocido y se necesita estabilizarlo
- Antes de un release importante o migración crítica

**No usar para:** cambios de feature nuevos (usar `plan` + `test-driven-development`),
revisiones puntuales de PR (usar `requesting-code-review`), o debugging de un
solo bug aislado (usar `systematic-debugging`).

---

## El Mantra del Bug Slayer

```
NO PARA HASTA QUE NO QUEDE NINGUNO
PREPARAR → AUDITAR → ENCONTRAR → CORREGIR → VERIFICAR → REPETIR
```

---

## Las 7 Fases

| Fase | Nombre | Responsable |
|------|--------|-------------|
| **0** | Preparación del Proyecto | Agente Padre |
| **1** | Reconocimiento | Agente Padre |
| **2** | Auditoría Multi-Agente o Manual | 3 Agentes Especializados / Agente Padre |
| **3** | Espera + Verificación | Agente Padre |
| **4** | Consolidación del Reporte | Agente Padre |
| **5** | Exterminación de Bugs | Agente Padre + Fix Agents |
| **6** | Verificación de Cero Bugs | Agente Padre |
| **7** | Prevención (Opcional) | Agente Padre |

---

## Fase 0: Preparación del Proyecto (Agente Padre)

Antes de auditar, verificar que el proyecto está listo para una auditoría segura.

### 0.1 Verificar Control de Versiones
```bash
cd <project_dir>
git status 2>/dev/null || echo "NO HAY GIT INICIALIZADO"
```

**Si NO hay Git:**
- Advertir al usuario: "El proyecto no tiene control de versiones. Los cambios serán irreversibles."
- Ofrecer inicializar Git antes de proceder: `git init && git add -A && git commit -m "Pre-bug-slayer baseline"`
- Si el usuario declina, hacer backup manual: `cp -r <project_dir> <project_dir>.backup-$(date +%Y%m%d-%H%M%S)`
- Documentar en el reporte que no hay rollback posible

**Si hay Git:**
- Verificar que el working tree está limpio: `git status --short`
- Si hay cambios sin commit, ofrecer hacer commit antes de la auditoría

### 0.3 Pre-flight Check de Delegación (Obligatorio)

Antes de lanzar agentes de auditoría, validar que el framework de delegación funciona.

**Importante:** `delegate_task` es **asíncrono**. Cuando reporta `dispatched`, el resultado vuelve más tarde como mensaje `[ASYNC DELEGATION BATCH COMPLETE]`. `process(action='list')` puede estar vacío inmediatamente después del dispatch; **esto NO significa fallo**.

```python
delegate_task(
    goal="Pre-flight check: reporta 'OK' y nada más.",
    context="Este es un pre-flight check. Responde exactamente 'OK'.",
    role="leaf",
    toolsets=["terminal"]
)
```

**Procedimiento correcto:**
1. Lanzar el pre-flight.
2. Esperar el mensaje asíncrono de finalización (típicamente 3–30 segundos).
3. Si el mensaje indica éxito y el agente retornó `OK`, la delegación funciona → proceder con Fase 2.
4. Si **después de 2–3 minutos** no llega mensaje async ni `process(action='list')` muestra actividad, entonces asumir fallo silencioso y usar auditoría manual.

**No hacer:** Llamar `process(action='list')` inmediatamente y declarar fallo si está vacío. Ver `references/async-delegation-behavior.md`.

### 0.2 Crear Backup (si no hay Git)
```bash
cp -r <project_dir> <project_dir>.bug-slayer-backup-$(date +%Y%m%d-%H%M%S)
```

**Regla de oro:** Nunca modificar archivos sin un camino de vuelta.

---

## Fase 1: Reconocimiento (Agente Padre)

Escaneo rápido para entender el alcance del proyecto. Solo lo suficiente para
briefear a los agentes especializados.

```bash
# Estructura del proyecto
find <project_dir> -type f | head -50

# Líneas de código por tipo
find <project_dir> -type f \( -name "*.py" -o -name "*.js" -o -name "*.ts" -o -name "*.go" -o -name "*.rs" \) | xargs wc -l | tail -1

# Archivos de configuración clave
ls -la <project_dir>/{Dockerfile,docker-compose*.yml,requirements.txt,package.json,go.mod,Cargo.toml,.env*} 2>/dev/null

# Tests existentes
find <project_dir> -type f -name "*test*" | wc -l
```

Leer SOLO estos archivos críticos:
- `requirements.txt` / `package.json` / `go.mod` / `Cargo.toml` — dependencias
- `Dockerfile` — contenerización
- `.env.example` — manejo de configuración y secretos
- `README.md` — visión general del proyecto
- Los 2-3 archivos fuente más grandes (para entender arquitectura)

**DETENERSE AQUÍ.** No leer más archivos. Los subagentes harán el trabajo detallado.

---

## Fase 2: Auditoría Multi-Agente (Paralela) o Manual

**Si el pre-flight check de Fase 0.3 fue exitoso:** lanzar 3 agentes especializados en paralelo usando `delegate_task` con modo batch.

**Si el pre-flight check falló o el proyecto tiene >5000 líneas:** usar **Auditoría Manual Directa** (sección 2.4).

### 2.1 Matriz de Decisión: Agentes vs Manual

| Condición | Acción recomendada |
|-----------|-------------------|
| Proyecto ≤ 2000 líneas y pre-flight OK | Usar 3 agentes en paralelo |
| Proyecto 2000-5000 líneas y pre-flight OK | Usar 3 agentes con monitoreo cada 5 min |
| Proyecto > 5000 líneas | Usar auditoría manual por defecto (más confiable) |
| Pre-flight check falla | Usar auditoría manual inmediatamente |
| Segunda falla de agentes | Usar auditoría manual; no re-lanzar más |

### ⚠️ REGLA INQUEBRANTABLE PARA AGENTES DE AUDITORÍA

> **LOS AGENTES DE AUDITORÍA SON READ-ONLY. NUNCA MODIFICAN ARCHIVOS.**
>
> Prohibido estrictamente:
> - `patch()` — NO corregir código durante auditoría
> - `write_file()` — NO escribir archivos
> - `skill_manage()` — NO modificar skills
> - Cualquier herramienta que modifique el filesystem
>
> Permitido:
> - `read_file()` — Leer código
> - `search_files()` — Buscar patrones
> - `terminal()` — Ejecutar comandos de solo-lectura (grep, wc, find)
> - `web_search()` / `web_extract()` — Investigar documentación
>
> Violación = auditoría inválida. El agente debe reportar bugs como texto plano,
> NUNCA aplicar fixes.

### Agente 1 — Cazador de Bugs Críticos (Seguridad + Estabilidad)
> **REGLA FUNDAMENTAL: SOLO LECTURA. NO MODIFICAR ARCHIVOS.**
> Eres un cazador de bugs críticos. Tu trabajo es ENCONTRAR y DESCRIBIR
> vulnerabilidades. NO arregles nada. NO uses patch, write_file, ni ninguna
> herramienta que modifique archivos. Solo lee y reporta.
>
> Revisa TODOS los archivos del proyecto en `<project_dir>`.
>
> ## Antes de reportar, verifica lo siguiente
> - Si hay una función de sanitización o escape, NO reportes inyección a menos que encuentres un bypass.
> - Si una variable de entorno se valida con Pydantic/BaseSettings, NO reportes "falta validación".
> - Si una operación crítica está protegida por `asyncio.Lock`, threading.Lock, o semáforo, NO reportes race condition.
> - Si el código usa `sqlite3.connect(..., check_same_thread=False)` sin WAL, SÍ reporta como CRÍTICO/ALTO.
> - Si `except:` o `except Exception:` hace `pass`, SÍ reporta como MEDIO/ALTO.
>
> ## Busca específicamente
> 1. **Seguridad:** secretos hardcodeados, inyección SQL/XSS/CSRF, path traversal,
>    eval/exec con input de usuario, deserialización insegura, autenticación débil.
> 2. **Estabilidad:** race conditions, deadlocks, memory leaks, null pointer dereference,
>    divisiones por cero, loops infinitos, recursión sin base case.
> 3. **Integridad de datos:** transacciones sin commit/rollback, operaciones no atómicas,
>    validación de entrada faltante, sanitización incompleta.
> 4. **Errores de concurrencia:** shared state sin sincronización, SQLite sin WAL mode,
>    callbacks sin manejo de errores.
> 5. **Configuración:** secretos en .env.example, passwords por defecto inseguros, variables sin validación.
> 6. **RAG específico:** prompt injection, retrieval sin umbral de score, LLM devolviendo None sin guarda, contexto expuesto al usuario.
>
> ## Formato obligatorio para cada hallazgo
> ```
> SEVERIDAD: CRÍTICO|ALTO|MEDIO|BAJO
> ARCHIVO: <ruta>:<línea>
> EVIDENCIA: <cita exacta de 1-3 líneas>
> IMPACTO: <qué puede pasar si se explota>
> REPRODUCCIÓN: <pasos mínimos>
> SOLUCIÓN: <código corregido como texto, NO aplicar>
> ```
>
> Si no encuentras bugs en una categoría, responde explícitamente: "Sin hallazgos en <categoría>".
### Agente 2 — Cazador de Bugs Funcionales (Lógica + APIs + Integraciones)
> **REGLA FUNDAMENTAL: SOLO LECTURA. NO MODIFICAR ARCHIVOS.**
> Eres un cazador de bugs funcionales. Tu trabajo es ENCONTRAR y DESCRIBIR
> errores de lógica. NO arregles nada. NO uses patch, write_file, ni ninguna
> herramienta que modifique archivos. Solo lee y reporta.
>
> Revisa TODOS los archivos del proyecto en `<project_dir>`.
>
> ## Antes de reportar, verifica lo siguiente
> - Si una función valida inputs con Pydantic, type hints o raises ValueError, NO reportes "falta validación".
> - Si un test tiene assertions que varían con datos, NO reportes "siempre verde".
> - Si un retry tiene `backoff` o `tenacity`, NO reportes "reintentos sin backoff".
> - Si un endpoint devuelve un error HTTP y lo loguea, NO reportes "manejo de errores inconsistente" salvo que haya fugas de información.
>
> ## Busca específicamente
> 1. **Lógica de negocio:** cálculos incorrectos, edge cases no manejados,
>    state machines con transiciones inválidas, algoritmos con complejidad incorrecta.
> 2. **APIs:** validación de request/response incompleta, HTTP methods incorrectos,
>    status codes equivocados, manejo de errores HTTP inconsistente.
> 3. **Integraciones:** timeouts faltantes, reintentos sin backoff, manejo de errores
>    de APIs externas, webhooks sin verificación de firma.
> 4. **Flujo de datos:** transformaciones incorrectas, pérdida de datos en pipelines,
>    encoding/decoding erróneo, serialización inconsistente.
> 5. **Tests:** tests que no prueban lo que dicen, tests siempre verdes, mocks
>    que no reflejan comportamiento real, cobertura baja en lógica crítica.
> 6. **RAG específico:** prompt injection, contexto truncado incorrectamente, retrieval con scores bajos no filtrados, LLM que devuelve None sin manejo.
>
> ## Formato obligatorio para cada hallazgo
> ```
> SEVERIDAD: CRÍTICO|ALTO|MEDIO|BAJO
> ARCHIVO: <ruta>:<función>:<línea>
> COMPORTAMIENTO ESPERADO: <qué debería pasar>
> COMPORTAMIENTO ACTUAL: <qué pasa ahora>
> CASO DE TEST: <código mínimo que reproduce el bug>
> SOLUCIÓN: <código corregido como texto, NO aplicar>
> ```
>
> Si una función parece compleja pero correcta, incluye un análisis de por qué no es un bug.
### Agente 3 — Cazador de Bugs de Calidad (Arquitectura + Rendimiento + Deuda Técnica)
> **REGLA FUNDAMENTAL: SOLO LECTURA. NO MODIFICAR ARCHIVOS.**
> Eres un cazador de bugs de calidad. Tu trabajo es ENCONTRAR y DESCRIBIR
> problemas de arquitectura con impacto demostrable. NO arregles nada. NO uses patch,
> write_file, ni ninguna herramienta que modifique archivos. Solo lee y reporta.
>
> Revisa TODOS los archivos del proyecto en `<project_dir>`.
>
> ## Calibración de severidad obligatoria
> - **CRÍTICO:** Solo si el problema causa caídas, pérdida de datos, o bloquea despliegue seguro.
> - **ALTO:** Impacto claro en performance, escalabilidad o mantenibilidad a 3 meses.
> - **MEDIO:** Deuda técnica que dificulta cambios, pero no bloquea.
> - **BAJO:** Code smell o documentación obsoleta; incluir solo si hay riesgo acumulado.
>
> ## Antes de reportar, verifica lo siguiente
> - Si hay un `README` o docstring que explica el global state, NO reportes como "global state malo" salvo que cause bugs.
> - Si el Dockerfile usa `USER nonroot` o `USER 1000`, NO reportes "usuario root".
> - Si hay tests que cubren la lógica crítica, NO reportes "cobertura baja" en esa área.
> - Si una función es larga pero cohesiva y bien nombrada, evalúa si realmente necesita división.
>
> ## Busca específicamente
> 1. **Arquitectura:** acoplamiento fuerte, violación de SRP, dependencias circulares,
>    global state con side effects, funciones monolíticas que dificultan tests.
> 2. **Rendimiento:** N+1 queries, falta de caching, carga de datos innecesaria,
>    algoritmos O(n²) donde debería ser O(n), memory leaks.
> 3. **Deuda técnica:** código duplicado crítico, magic numbers en lógica de negocio,
>    comentarios obsoletos que inducen a error, funciones >500 líneas con múltiples responsabilidades.
> 4. **Configuración:** variables de entorno sin validación, defaults peligrosos,
>    configuración hardcodeada, secretos en logs.
> 5. **Observabilidad:** logs sin estructura, métricas faltantes, tracing ausente,
>    errores que se tragan silenciosamente (except: pass).
> 6. **Docker/Deploy:** multi-stage builds faltantes, usuario root, imágenes grandes, secretos en imágenes.
>
> ## Formato obligatorio para cada hallazgo
> ```
> SEVERIDAD: CRÍTICO|ALTO|MEDIO|BAJO
> ARCHIVO: <ruta>:<componente>
> IMPACTO REAL: <qué puede ocurrir en 1-3 meses si no se arregla>
> EVIDENCIA: <cita de código o métrica>
> REFACTOR SUGERIDO: <descripción o pseudocódigo, NO aplicar>
> ```
>
> Separa "problemas reales" de "preferencias de estilo".
### Agente 4 — Verificador de Hallazgos (Opcional, post-auditoría)
> **REGLA FUNDAMENTAL: SOLO LECTURA. NO MODIFICAR ARCHIVOS.**
> Eres un verificador. Recibirás una lista de hallazgos de otros agentes.
> Tu trabajo es validar si cada hallazgo es real o falso positivo.
> NO arregles nada. NO uses patch, write_file ni herramientas destructivas.
>
> Para cada hallazgo recibido:
> 1. Leer el archivo y línea indicados.
> 2. Decidir: CONFIRMADO / FALSO POSITIVO / PARCIAL / YA CORREGIDO.
> 3. Justificar con evidencia de código exacta.
> 4. Si falta evidencia, pedir al agente original que la agregue.

---

## Fase 3: ESPERAR Resultados + Verificación (REGLA CRÍTICA)

**Regla de oro:** Después de lanzar los agentes, NO continuar leyendo archivos ni
haciendo análisis adicional. El usuario prefiere esperar el reporte consolidado.

### 3.1 Verificación de Integridad Post-Auditoría

Cuando los agentes retornen, verificar que NO modificaron archivos:

```bash
cd <project_dir>

# Si hay Git:
git status --short
# Si hay cambios, los agentes modificaron archivos (INACEPTABLE)

# Si NO hay Git, verificar timestamps:
find . -name "*.py" -mmin -30 | head -20
# Si hay archivos recientemente modificados, los agentes tocaron archivos
```

**Si los agentes modificaron archivos:**
1. Reportar al usuario: "⚠️ Los agentes de auditoría modificaron archivos durante el reconocimiento. Esto no debería ocurrir."
2. Mostrar qué archivos fueron modificados
3. Ofrecer opciones:
   - Revertir cambios (si hay Git: `git checkout -- .`)
   - Conservar cambios y proceder (riesgo: cambios no probados)
   - Hacer backup antes de continuar

**Por qué esto importa:**
- Los agentes de auditoría deben ser READ-ONLY
- Si modifican archivos, pueden introducir bugs no probados
- Mezcla auditoría + fix dificulta saber qué estaba roto vs. qué ya está "arreglado"
- Sin Git, los cambios son irreversibles

### 3.2 Monitoreo Proactivo de Agentes (OBLIGATORIO para proyectos >5000 líneas)

**El usuario prefiere monitoreo proactivo.** Verificar estado de subagentes periódicamente, especialmente en proyectos grandes.

**Frecuencia obligatoria:**
- Proyectos >5000 líneas: Cada 2-3 minutos
- Proyectos 2000-5000 líneas: Cada 5 minutos
- Proyectos <2000 líneas: Al finalizar, verificar una vez

**Comandos de verificación:**
```bash
# 1. Verificar procesos activos
process(action='list')

# 2. Verificar logs de delegación
grep -E "deleg_<id>" ~/.hermes/logs/agent.log | tail -20

# 3. Verificar timestamps de archivos (detectar modificaciones)
cd <project_dir> && find . -name "*.py" -mmin -10 | head -10

# 4. Verificar si archivos nuevos fueron creados
find . -type f -mmin -10 | grep -v __pycache__ | grep -v .git
```

**Señales de problemas y acciones:**

| Señal | Significado | Acción |
|-------|-------------|--------|
| `process(action='list')` vacío después de 5 minutos | Agentes no iniciaron | Re-lanzar con `delegate_task` o usar auditoría manual |
| No hay registros en `~/.hermes/logs/agent.log` | Delegación falló silenciosamente | Usar auditoría manual directa inmediatamente |
| Agentes no retornan después de 15 minutos | Timeout o loop infinito | Cancelar y usar auditoría manual |
| Archivos modificados durante auditoría | Violación READ-ONLY | Revertir cambios, re-lanzar con reglas más estrictas |
| Errores en resultados de agentes | Fallo parcial | Evaluar si el reporte es usable o re-lanzar |

**Regla de recuperación:**
1. **Primera falla:** Re-lanzar `delegate_task` con contexto más específico
2. **Segunda falla:** Proceder con **auditoría manual directa** (Fase 2.4)
3. **Nunca re-lanzar más de 2 veces** — el framework de delegación tiene problemas persistentes

### 2.4 Auditoría Manual Directa (Opción Principal para Proyectos Grandes)

**Cuándo usar:**
- Proyecto tiene >5000 líneas (modo por defecto, más confiable).
- Subagentes no retornan después de 15 minutos.
- `process(action='list')` vacío después de 5 minutos (agentes no iniciaron).
- No hay registros de delegación en logs.
- Segunda falla consecutiva de subagentes.
- Pre-flight check de Fase 0.3 falló.

**Proceso de auditoría manual:**

1. **Reconocimiento** (igual que Fase 1)
   - Estructura, métricas, archivos críticos

2. **Análisis por patrones** (secuencial, categoría por categoría)
   ```bash
   # Buscar patrones de bugs comunes
   search_files(pattern="except:", path="<project_dir>", file_glob="*.py")
   search_files(pattern="os\.getenv\(.*,\s*\"", path="<project_dir>", file_glob="*.py")
   search_files(pattern="print\(", path="<project_dir>", file_glob="*.py")
   search_files(pattern="eval\(|exec\(", path="<project_dir>", file_glob="*.py")
   search_files(pattern="MD5|md5", path="<project_dir>", file_glob="*.py")
   search_files(pattern="subprocess|os\.system", path="<project_dir>", file_glob="*.py")
   search_files(pattern="sqlite3\.connect", path="<project_dir>", file_glob="*.py")
   search_files(pattern="logging\.basicConfig", path="<project_dir>", file_glob="*.py")
   search_files(pattern="tempfile|mkdtemp", path="<project_dir>", file_glob="*.py")
   ```

3. **Análisis de archivos críticos** (leer secciones clave)
   - Leer primeras 100 líneas de archivos principales
   - Leer funciones de autenticación, validación, manejo de archivos
   - No leer archivos completos si son >500 líneas

4. **Consolidación** (igual que Fase 4)
   - Agrupar bugs por severidad
   - Deduplicar por archivo:línea

**Ventajas:** No depende del framework de delegación, control total, más rápido que esperar agentes fallidos.
**Desventajas:** Más lento que agentes paralelos, requiere más contexto del agente padre.

**Regla:** Si los agentes fallan 2 veces, usar auditoría manual. No insistir
con re-lanzamientos indefinidos.

### 3.2 Señales de Loop de Lectura

- Has leído el mismo archivo 3+ veces
- Quieres leer "solo un archivo más"
- El usuario dice "voy a esperar el reporte consolidado"
- El sistema advierte sobre "repeated_exact_failure_warning"

**Recuperación:** Si te das cuenta de que estás en un loop, detener TODAS las
llamadas a herramientas inmediatamente y decir: "Entendido. Me detengo para
evitar más lecturas redundantes. Esperaré los resultados de los agentes."

### 3.3 Verificación de Hallazgos (Obligatoria)

Antes de crear TODOs, verificar cada hallazgo de los 3 agentes.

**Pasos:**
1. Para cada hallazgo CRÍTICO, leer el archivo y línea exactos.
2. Para cada hallazgo ALTO, leer la función o bloque referenciado.
3. Clasificar: CONFIRMADO / FALSO POSITIVO / PARCIAL / YA CORREGIDO.
4. Documentar clasificación en notas de verificación (ver `references/verifying-bug-slayer-findings.md`).
5. Solo crear TODOs para hallazgos CONFIRMADOS o PARCIALES.

**Regla:** Si un agente reporta más de 3 hallazgos sin evidencia de código, marcar los sin evidencia como FALSO POSITIVO y pedir que el agente los rehaga.

---

## Fase 4: Consolidación del Reporte de Bugs

Cuando todos los agentes retornen, consolidar en un reporte unificado:

```markdown
# 🐛🔥 REPORTE BUG SLAYER — <Nombre del Proyecto>

## Resumen Ejecutivo
[2-3 oraciones sobre salud general y top 3 preocupaciones]
- Total de bugs encontrados: X
- Críticos: X | Altos: X | Medios: X | Bajos: X
- Estado: [ENCONTRADOS] → [CORRIGIENDO] → [VERIFICANDO] → [CERO BUGS]

## 🔴 CRÍTICOS (Acción inmediata — caídas, seguridad, pérdida de datos)
| ID | Archivo | Línea | Descripción | Solución |
|----|---------|-------|-------------|----------|
| C1 | ... | ... | ... | ... |

## 🟠 ALTOS (Esta semana — funcionalidad rota, performance)
| ID | Archivo | Línea | Descripción | Solución |
|----|---------|-------|-------------|----------|
| H1 | ... | ... | ... | ... |

## 🟡 MEDIOS (Este mes — deuda técnica, edge cases)
| ID | Archivo | Línea | Descripción | Solución |
|----|---------|-------|-------------|----------|
| M1 | ... | ... | ... | ... |

## 🟢 BAJOS (Backlog — mejoras incrementales)
| ID | Archivo | Línea | Descripción | Solución |
|----|---------|-------|-------------|----------|
| L1 | ... | ... | ... | ... |

## Métricas del Proyecto
| Métrica | Valor |
|---------|-------|
| Líneas totales | X |
| Archivos | X |
| Tests existentes | X |
| Cobertura estimada | X% |
| Bugs por cada 1000 líneas | X |
```

**Regla de deduplicación:** Si múltiples agentes encuentran el mismo bug,
deduplicar por archivo:línea. Mantener la descripción más detallada.

---

## Fase 5: Exterminación de Bugs (Corrección)

Cuando el usuario diga "Comienza con la implementación", "Extermina los bugs",
o "Procede con la corrección":

### 5.1 Crear Lista de Tareas (TODO)

Crear TODOs para TODOS los bugs, organizados por severidad:

```python
todo(todos=[
    {"id": "bug-c1", "content": "[CRÍTICO] Fix race condition in...", "status": "pending"},
    {"id": "bug-c2", "content": "[CRÍTICO] Remove hardcoded API key...", "status": "pending"},
    {"id": "bug-h1", "content": "[ALTO] Fix N+1 query in...", "status": "pending"},
    # ... TODOS los bugs
])
```

### 5.2 Procesar en Orden de Severidad

**Orden obligatorio:** CRÍTICO → ALTO → MEDIO → BAJO

**No detenerse después de críticos o altos.** El usuario quiere TODOS los bugs
eliminados, no solo los graves.

### 5.3 Patrón de Corrección por Bug

```python
# 1. Marcar como en progreso
todo(todos=[{"id": "bug-c1", "status": "in_progress"}])

# 2. Leer las líneas específicas que necesitan cambio
read_file(path="src/file.py", offset=100, limit=50)

# 3. Aplicar el fix con patch
patch(path="src/file.py", old_string="...", new_string="...")

# 4. Verificar el fix (tests, lint, compilación)
terminal(command="pytest tests/test_module.py::test_regression -v")

# 5. Marcar como completado
todo(todos=[{"id": "bug-c1", "status": "completed"}])
```

### 5.4 Reglas de Corrección

- **Solo parchear lo que ya se ha leído y verificado.** No parchear a ciegas.
- **Si patch falla dos veces con argumentos idénticos:** Detenerse y releer el
  archivo. El contenido ha cambiado o el old_string es incorrecto. No reintentar
  una tercera vez con los mismos argumentos — eso es un loop.
- **Un cambio a la vez.** No agrupar múltiples fixes en un solo patch.
- **Crear test de regresión para cada bug crítico y alto.**
- **Verificar que no se introducen nuevos bugs:** correr test suite completa
  después de cada batch de severidad.

---

## Fase 6: Verificación de Cero Bugs

Después de corregir todos los bugs:

### 6.1 Verificación Estática
```bash
# Re-ejecutar los 3 agentes de auditoría en modo verificación
# Buscar: "¿Quedó algún bug?"
```

### 6.2 Verificación Dinámica
```bash
# Correr toda la suite de tests
pytest tests/ -v

# Verificar linting y tipos
ruff check . && mypy . --ignore-missing-imports

# Verificar cobertura
pytest --cov=src --cov-report=term-missing
```

### 6.3 Verificación Manual
- Revisar los archivos modificados con `git diff`
- Asegurar que no quedan `print()` de debug, `except: pass`, o comentarios temporales
- Verificar que todos los tests de regresión pasan

### 6.4 Reporte Final
```markdown
# ✅ REPORTE BUG SLAYER — FASE COMPLETADA

## Estado: CERO BUGS ALCANZADO

### Bugs Exterminados
| Severidad | Cantidad | Estado |
|-----------|----------|--------|
| Crítico | X | ✅ Eliminados |
| Alto | X | ✅ Eliminados |
| Medio | X | ✅ Eliminados |
| Bajo | X | ✅ Eliminados |
| **Total** | **X** | **✅ CERO** |

### Tests de Regresión Creados
- [Lista de tests nuevos que previenen recurrencia]

### Archivos Modificados
- [Lista de archivos con número de líneas cambiadas]

### Métricas de Calidad Post-Exterminio
| Métrica | Antes | Después |
|---------|-------|---------|
| Bugs totales | X | 0 |
| Tests | X | X |
| Cobertura | X% | X% |
| Deuda técnica | X | X |

## 🎉 Misión Cumplida
El proyecto está limpio. No queda ningún bug.
```

### 6.5 Verificación de Despliegue (Obligatoria si el proyecto usa Docker)

Incluso si el repo local está limpio y todos los tests pasan, el despliegue Docker puede estar ejecutando una imagen antigua o contener errores que no existen en el repo. Verificar:

1. **Listar contenedores activos:**
   ```bash
   docker ps --format "table {{.Names}}\t{{.Status}}\t{{.Ports}}"
   ```

2. **Detectar contenedores en bucle de reinicio o unhealthy:**
   - `Restarting (N)` indica que el proceso principal falla al arrancar.
   - `unhealthy` indica que el healthcheck está fallando.

3. **Leer logs de los contenedores problemáticos:**
   ```bash
   docker logs --tail 50 <container_name>
   ```

4. **Clasificar el origen del error:**
   - **Error de código que ya fue corregido en el repo** → la imagen Docker está desactualizada. Reconstruir y redeployar.
   - **Error que aún existe en el repo** → corregir en el código, commitear, y luego reconstruir la imagen.
   - **Error de configuración** (ej. token faltante) → revisar variables de entorno y `.env`.

5. **Reconstruir y redeployar si es necesario:**
   ```bash
   docker compose -f <compose-file> build --no-cache
   docker compose -f <compose-file> up -d
   ```

6. **Verificar nuevamente los logs y el estado de salud:**
   ```bash
   docker ps --format "table {{.Names}}\t{{.Status}}"
   docker logs --tail 20 <container_name>
   ```

**Regla:** Nunca dar por terminada una misión Bug Slayer sin verificar que el despliegue activo refleja el código corregido. Ver `references/session-lessons-2026-07-08-deploy-sync.md`.

---

## Fase 7: Prevención (Opcional)

Si el usuario lo solicita, establecer guardas para prevenir futuros bugs:

1. **Pre-commit hooks:** lint, tests, security scan
2. **CI/CD pipeline:** tests automáticos en cada PR
3. **Monitoreo:** alertas de errores en producción
4. **Revisión periódica:** re-ejecutar Bug Slayer cada sprint/mes

---

## Integración con Otros Skills

- **multi-agent-auditing:** Bug Slayer usa sus agentes especializados como base
- **systematic-debugging:** Usar cuando un bug específico necesita análisis de raíz
- **requesting-code-review:** Verificar cada fix antes de marcarlo completo
- **test-driven-development:** Crear tests de regresión para cada bug crítico/alto
- **plan:** Crear plan de remediación si hay demasiados bugs para una sola sesión

---

## Pitfalls

- **Auditoría manual por defecto en proyectos grandes:** Para proyectos >5000 líneas, no esperar a que los agentes fallen. Usar auditoría manual directa desde Fase 2. El framework de delegación ha demostrado ser poco confiable en proyectos grandes.
- **Patrón de fallo silencioso de subagentes:** Cuando `delegate_task` reporta "dispatched" pero no hay logs ni resultado inmediato, **no asumir fallo de inmediato**. Los resultados pueden llegar como mensaje async `[ASYNC DELEGATION BATCH COMPLETE]`. Si el resultado llega en segundos o pocos minutos, la delegación funciona. Si después de 2–3 minutos no hay actividad, recién entonces asumir fallo silencioso y usar auditoría manual. Ver `references/async-delegation-behavior.md`.
- **Preferencia del usuario por implementación manual:** Cuando se ofrecen opciones después de fallos de subagentes, el usuario prefiere implementación manual sobre re-lanzar subagentes. No ofrecer re-lanzar como primera opción después de fallos previos.
- **Cookie security en Streamlit:** `extra_streamlit_components.CookieManager` no soporta `HttpOnly`, `Secure`, `SameSite`. Usar JavaScript injection como fallback para establecer atributos de seguridad.
- **Async lock para inicialización:** Reemplazar booleanos `is_loading` por `asyncio.Lock()` para prevenir condiciones de carrera en inicialización de recursos compartidos.
- **Rate limiting en Streamlit:** Usar `st.session_state` para contadores de intentos fallidos y bloqueo temporal, ya que no hay middleware de request como en FastAPI/Flask.
- **Auditoría sin Git:** Nunca auditar un proyecto sin control de versiones sin preparación previa. Los agentes pueden modificar archivos accidentalmente y sin Git no hay rollback. Verificar `git status` antes de empezar. Ver `references/audit-without-git.md`.
- **Agentes que modifican archivos durante auditoría:** Si los agentes reportan "fixes aplicados" o `git status` muestra cambios post-auditoría, detener todo. Los agentes de auditoría deben ser READ-ONLY. Revertir cambios y re-lanzar.
- **No detenerse después de severidad alta:** El usuario quiere TODOS los bugs eliminados, incluyendo medios y bajos.
- **Loop de lectura después de dispatch:** No leer archivos una vez lanzados los agentes. Esperar el reporte consolidado.
- **Parchear a ciegas:** Siempre leer antes de parchear. Si patch falla dos veces, releer el archivo.
- **Olvidar tests de regresión:** Cada bug crítico/alto debe tener un test que lo prevenga de volver.
- **Re-lanzar auditoría sin verificar estado previo:** Si una auditoría anterior falló o los agentes no retornaron, siempre verificar el estado del proyecto antes de re-lanzar. Los agentes anteriores podrían haber modificado archivos incluso si fallaron. Usar `git status` o timestamps para confirmar integridad.
- **Agentes que no retornan ni aparecen en logs:** Si `delegate_task` reporta "dispatched" pero los agentes no aparecen en `process(action='list')` ni en los logs, el framework de delegación puede haber fallado silenciosamente. Verificar:
  1. `process(action='list')` — Si no hay procesos, los agentes no iniciaron
  2. `grep <delegation_id> ~/.hermes/logs/agent.log` — Si no hay registros, la delegación falló
  3. Si los agentes no iniciaron, re-lanzar `delegate_task` o proceder con **auditoría manual directa**
- **Auditoría manual como fallback:** Si los agentes fallan 2 veces consecutivas o no retornan después de 15 minutos, proceder con auditoría manual directa. Ver `references/session-lessons-2026-06-26.md` para el proceso completo.
- **Verificación de path antes de delegar:** Siempre confirmar el path real del proyecto con `pwd` o `ls` antes de proporcionarlo a los subagentes. No confiar en paths reportados por otros agentes. Usar paths absolutos en el contexto.
- **Duplicidad de rutas del mismo proyecto:** Antes de reportar status o continuar con auditoría, verificar si existen múltiples copias del proyecto (por ejemplo, `~/proyecto` y `~/Documentos/Proyectos/proyecto`). Comparar `git log --oneline` y `git status` entre rutas candidatas. Nunca asumir que la ruta más obvia es el repo activo. Si se detecta duplicidad, reportarla explícitamente y pedir al usuario confirmar cuál es el repo principal antes de sincronizar. Ver `references/session-lessons-2026-07-06-status.md`.
- **Implementación manual como fallback de implementación:** Si los subagentes de implementación fallan 2 veces consecutivas o no retornan después de 15 minutos, proceder con implementación manual directa. El usuario prefiere esto sobre re-lanzar subagentes indefinidamente. Ver `references/session-lessons-2026-06-26.md`.
- **No declarar 'cero bugs' sin verificar el despliegue:** Una auditoría no termina cuando el repo está limpio. Si el proyecto usa Docker, verificar que los contenedores activos no estén en bucle de reinicio ni ejecutando una imagen desactualizada. Ver `references/session-lessons-2026-07-08-deploy-sync.md`.
- **`await` en métodos de inicialización sincrónicos:** Un método `__init__` o `initialize_*()` no puede usar `await`. Guardar el mensaje de error en `self._engine_error` y responder desde el handler async. Ver `references/session-lessons-2026-07-08-deploy-sync.md`.
- **Olvidar actualizar el CHANGELOG:** Después de un exterminio, agregar una entrada al CHANGELOG que documente las fases ejecutadas, bugs corregidos y tests de verificación. Es parte de la trazabilidad. Ver `references/session-lessons-2026-07-08-deploy-sync.md`.
- **Asumir que un desfase entre reportes viene por filtros:** Antes de eso, hacer diff por DTV/factura entre la vista autoritativa y la vista de detalle. Encomisiones, la diferencia puede ser un registro ausente en `detalle_comisiones_pendientes` aunque `detalle_comisiones_denegadas` y `comisiones_a_pagar` estén vacíos para ese usuario. Ver `references/commission-report-discrepancy-debugging.md`.

---

## Referencias de Severidad

| Severidad | Definición | Tiempo de Respuesta | Ejemplos |
|-----------|-----------|---------------------|----------|
| **CRÍTICO** | Causa caída, compromiso de seguridad, pérdida de datos | Inmediato | SQL injection, race condition en transacción, null pointer en producción |
| **ALTO** | Funcionalidad rota, performance inaceptable, bug de lógica | Esta semana | N+1 queries, algoritmo incorrecto, API que devuelve datos erróneos |
| **MEDIO** | Edge case no manejado, deuda técnica, workaround existe | Este mes | Falta de validación en campo opcional, código duplicado, except: pass |
| **BAJO** | Mejora incremental, code smell, documentación | Backlog | Nombre de variable poco claro, falta de type hints, comentario obsoleto |

---

## Archivos de Referencia del Skill

- `references/session-lessons-2026-06-26.md` — Lecciones aprendidas de la sesión del 26 de junio de 2026. Incluye problemas reales con subagentes que fallan silenciosamente, paths incorrectos, lazy loading para env vars, y métricas de la sesión.
- `references/session-lessons-2026-07-08-deploy-sync.md` — Lecciones de la sesión del 8 de julio de 2026: reconstrucción de estado de agentes multi-fase a posteriori, verificación de despliegue Docker post-exterminio, patrón para manejar `await` en métodos de inicialización sincrónicos, y actualización del CHANGELOG como trazabilidad.
- `references/session-lessons-2026-06-30.md` — Lecciones de la sesión del 30 de junio de 2026. Incluye problemas reales con subagentes que fallan silenciosamente, consentimiento de herramientas destructivas, embeddings 1D en tests, orden de evicción LRU en SQLite, separación de configuración para tests ligeros, y timestamps de alta precisión.
- `references/session-lessons-2026-06-30-incremental-refactor.md` — Lecciones de la sesión del 30 de junio de 2026: refactor del motor RAG (Robotito), indexación incremental, semáforo para QueryFusionRetriever, extracción de metadatos a sub-funciones, y reducción de `engine.py` usando un script de reemplazo por bloques.
- `references/session-lessons-2026-06-26.md` — Lecciones aprendidas de la sesión del 26 de junio de 2026. Incluye problemas reales con subagentes que fallan silenciosamente, paths incorrectos, lazy loading para env vars, y métricas de la sesión.
- `references/bug-fixing-patterns.md` — Snippets "antes/después" para los bugs más comunes. Usar durante la fase de exterminación.
- `references/async-delegation-behavior.md` — Lección aprendida: `delegate_task` es asíncrono; no asumir fallo silencioso por `process(action='list')` vacío inmediatamente después del dispatch. Ver procedimiento correcto y anti-patrón.
- `references/agent-monitoring-proactive.md` — Guía de monitoreo proactivo de subagentes durante auditorías. Incluye frecuencia de verificación, señales de fallo silencioso, protocolo de recuperación y lecciones aprendidas de sesiones reales.
- `references/audit-without-git.md` — Lección aprendida: cómo manejar auditorías sobre proyectos sin control de versiones. Incluye detección de agentes que modifican archivos y recuperación.
- `references/verifying-bug-slayer-findings.md` — Proceso de verificación de hallazgos antes de corrección, con criterios de clasificación y template de notas.
- `references/agent-monitoring.md` — Guía de monitoreo de subagentes durante auditorías largas. Incluye frecuencia de verificación, señales de problemas y recuperación.
- `templates/zero-bugs-report.md` — Template del reporte final cuando se alcanza cero bugs.
- `scripts/verify-zero-bugs.py` — Script de verificación automatizada para confirmar que no quedan bugs conocidos.
