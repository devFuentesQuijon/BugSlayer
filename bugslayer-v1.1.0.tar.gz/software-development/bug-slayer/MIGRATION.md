# Bug Slayer — Metodología framework agnóstica

> Contenido listo para adaptar a cualquier stack de herramientas, agentes o flujos de trabajo.

## Archivo generado

- `bugslayer-methodology.md` — metodología completa sin dependencias de Hermes