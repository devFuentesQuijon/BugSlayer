# Lecciones de la sesión del 30 de junio de 2026 — Refactor del motor RAG

## Contexto
Sesión de exterminación de bugs de un chatbot RAG para UCSH (Robotito). Se completaron Fases 5 y 6 de un plan de Bug Slayer, dejando solo el bug C1 (dividir monolito `app.py`).

## Patrones técnicos que emergieron

### 1. Extraer dependencias pesadas para hacer código testable
Algunos módulos de LlamaIndex (p. ej. `llama_index.retrievers.bm25`) no están disponibles en entornos de test livianos. En lugar de importar el retriever dentro del módulo de envoltorio, se coloca el wrapper en un archivo separado (`src/retriever_utils.py`) que solo importa `BaseRetriever` y `QueryBundle` del core. La importación del retriever concreto queda en el consumidor (`engine.py`).

**Resultado:** los tests del wrapper pueden ejecutarse sin tener que instalar el vector store completo.

### 2. Sustitución de grandes bloques de código con Python
La refactorización de `engine.py` requirió eliminar ~350 líneas de código duplicado (descifrado, manifiesto, re-indexación). En lugar de múltiples parches con `old_string`/`new_string`, se usó un script Python que:
- Busca un marcador de inicio y un marcador de fin.
- Reemplaza el bloque completo por una llamada a la nueva función.
- Verifica que el semáforo y las importaciones ya existen antes de modificar.

**Beneficio:** reduce el riesgo de parches parciales y evita loops de lectura.

### 3. Separar lógica de extracción de metadatos en sub-funciones
`extract_document_metadata` se extrajo a `src/metadata_extractor.py` dividiéndose en:
- `_detect_document_type`
- `_build_clean_title`
- `_fallback_concepts`
- `_extract_concepts_with_llm`
- `_load_metadata_cache` / `_save_metadata_cache`
- `_compute_content_hash`

Cada una recibe primitivos y devuelve primitivos, lo que facilita tests unitarios sin mocks de LlamaIndex.

### 4. Indexación incremental
Se reemplazó la re-indexación completa en cada arranque por un módulo `src/indexer.py` que:
- Calcula SHA-256 del contenido descifrado de cada archivo.
- Compara con el registro de la corrida anterior (`indexed_hashes.json`).
- Detecta `added`, `modified` y `removed`.
- Solo procesa los archivos que cambiaron, eliminando los nodos obsoletos y regenerando el manifiesto global.

**Clave:** el docstore y el vector store deben persistirse entre corridas; de lo contrario la indexación incremental no tiene sentido.

### 5. Semáforo async para QueryFusionRetriever
`QueryFusionRetriever` con `use_async=True` puede generar concurrencia descontrolada bajo carga concurrente. Se envolvió con `SemaphoredHybridRetriever`, que usa `asyncio.Semaphore` y adquiere el permiso en `aretrieve` y en el fallback síncrono `retrieve`.

## Errores evitados
- No reutilizar `pytest.mark.anyio` cuando el test crea tareas con `asyncio.create_task`; usar `pytest.mark.asyncio` con `pytest-asyncio` si el entorno no tiene `trio`.
- Verificar que el módulo de tests no importe dependencias pesadas a través del módulo bajo test.
- No confiar en los argumentos con nombre de `Document(...)`; LlamaIndex Document acepta `**data`, pero los nombres varían entre versiones.

## Métricas de la sesión
- Tests: 146 → 172 passed.
- `engine.py` reducido de ~459 líneas de lógica de indexación a ~52 líneas de llamadas al indexador.
- Nuevos módulos: `src/retriever_utils.py`, `src/metadata_extractor.py`, `src/indexer.py`.
- Nuevos tests: `tests/test_engine_retriever.py`, `tests/test_metadata_extractor.py`, `tests/test_indexer.py`.
