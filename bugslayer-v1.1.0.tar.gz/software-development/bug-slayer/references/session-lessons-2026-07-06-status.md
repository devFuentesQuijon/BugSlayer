# Lecciones de la sesión del 6 de julio de 2026 — Status del Bug Slayer y trazabilidad de rutas

## Contexto
El usuario pidió el status del agente Bug Slayer. No había un agente activo en la sesión actual, pero el trabajo del Bug Slayer había quedado registrado en sesiones anteriores y en commits de Git. Al reconstruir la trazabilidad, se descubrió que el mismo proyecto existía en dos rutas distintas con estados diferentes.

## Hallazgo clave: duplicidad de rutas del proyecto

| Ruta | Estado encontrado |
|------|-------------------|
| `/home/david/Documentos/Proyectos/IA/robotito` | Contiene commits de Fases 5 y 6 (`e56efcd`, `b87eb7e`) y CHANGELOG actualizado |
| `/home/david/robotito` | Solo tiene cambios locales sin commit; NO refleja Fases 5 y 6 |

Esto genera una trampa de trazabilidad: el agente puede asumir que el trabajo está aplicado en una ruta cuando en realidad está en otra, o viceversa.

## Lecciones aprendidas

1. **Al pedir status de un agente multi-fase, primero buscar el trabajo histórico** con `session_search` y `cronjob` antes de asumir que no hay nada en curso.
2. **Verificar si existen múltiples rutas del mismo proyecto** con `find` o `locate` antes de reportar status. Problemas comunes:
   - Proyecto clonado en múltiples ubicaciones (`~/proyecto`, `~/Documentos/Proyectos/proyecto`, `~/workspace/proyecto`).
   - Repos con y sin trabajo commiteado.
   - Copias de respaldo que parecen ser el repo activo.
3. **Confirmar cuál es la ruta "oficial"** antes de continuar. Indicadores:
   - Tiene más commits recientes o tags.
   - Contiene archivos de CI/CD o despliegue.
   - Es la ruta que el usuario ha mencionado previamente en sesiones recientes.
   - Tiene `origin` remoto configurado en Git.
4. **Reportar la discrepancia explícitamente** en el status para que el usuario decida si sincronizar o consolidar.
5. **No asumir que `pwd` o la ruta más obvia es el repo activo**. Preferir comparar `git log --oneline` y `git status` entre rutas candidatas.

## Comandos útiles para detectar duplicidad

```bash
# Buscar posibles rutas del proyecto
find /home -maxdepth 4 -type d -name "robotito" 2>/dev/null

# Comparar estado de Git entre rutas
for d in /home/david/robotito /home/david/Documentos/Proyectos/IA/robotito; do
  echo "=== $d ==="
  cd "$d" 2>/dev/null && git log --oneline -5 || echo "No es git"
done
```

## Acción recomendada cuando se detecta duplicidad

1. Pausar y reportar ambas rutas con sus estados.
2. Preguntar al usuario cuál es el repo principal.
3. Ofrecer opciones:
   - Sincronizar ambas vía `git pull` / `git push` / merge.
   - Archivar/copiar la ruta obsoleta con un sufijo `.backup-<fecha>`.
   - Hacer commit en la ruta activa y eliminar la duplicada.

## Relación con sesiones anteriores

- Ver `references/session-lessons-2026-06-30.md` para fallas de subagentes y monitoreo proactivo.
- Ver `references/session-lessons-2026-06-30-incremental-refactor.md` para el refactor del motor RAG de Robotito.
