# Monitoreo de Subagentes durante Auditorías

Guía para detectar y recuperarse cuando los agentes de auditoría fallan o no
retornan.

---

## Problema: Agentes que No Retornan

### Síntomas
- `delegate_task` reporta "dispatched" pero no hay notificación de completitud
- `process(action='list')` no muestra procesos activos después de varios minutos
- Los logs no contienen registros del `delegation_id`
- El usuario pregunta "¿Cómo van los agentes?" repetidamente

### Diagnóstico Rápido

```bash
# 1. Verificar procesos activos
process(action='list')

# 2. Verificar logs de delegación
grep -E "deleg_<id>" ~/.hermes/logs/agent.log | tail -20

# 3. Verificar timestamps de archivos (si los agentes modificaron algo)
cd <project_dir> && find . -name "*.py" -mmin -10 | head -10

# 4. Verificar estado de Git
cd <project_dir> && git status --short
```

### Interpretación de Resultados

| Resultado | Significado | Acción |
|-----------|-------------|--------|
| Procesos activos + logs con delegation_id | Agentes trabajando normalmente | Esperar |
| Sin procesos + sin logs | Agentes nunca iniciaron | Re-lanzar o usar auditoría manual |
| Sin procesos + logs de error | Agentes fallaron | Re-lanzar o usar auditoría manual |
| Archivos modificados | Violación READ-ONLY | Revertir y re-lanzar |

---

## Recuperación: Auditoría Manual Directa

Cuando los agentes de delegación fallan, el agente padre puede realizar la
auditoría directamente. Esto es más lento pero garantiza que se complete.

### Ventajas
- No depende del framework de delegación
- Control total sobre el proceso
- Puede manejar proyectos grandes sin timeout de subagentes

### Desventajas
- Más lento (un agente en lugar de tres paralelos)
- Requiere más contexto del agente padre
- Puede omitir bugs si el análisis no es exhaustivo

### Proceso de Auditoría Manual

1. **Reconocimiento** (igual que con agentes)
   - Estructura del proyecto
   - Archivos críticos
   - Métricas básicas

2. **Análisis por categorías** (secuencial en lugar de paralelo)
   - Seguridad: `search_files` para patrones críticos
   - Estabilidad: `search_files` para errores comunes
   - Calidad: `search_files` para deuda técnica
   - Funcional: Leer archivos principales y buscar lógica defectuosa

3. **Consolidación** (igual que con agentes)

---

## Lección Aprendida: Verificación de Path

**Problema:** En esta sesión, el agente funcional buscó archivos en
`robotito/robotito-main/` en lugar de `robotito/`. Esto causó que fallara
silenciosamente.

**Causa:** El contexto proporcionado al agente mencionó un path reportado por
otro agente anterior, que resultó ser incorrecto.

**Solución:**
- Siempre verificar el path real con `pwd` o `ls` antes de proporcionarlo a los
  subagentes
- No confiar en paths reportados por otros agentes
- Usar paths absolutos en el contexto: `/home/david/Documentos/Proyectos/IA/robotito`

---

## Frecuencia de Monitoreo

| Tamaño del proyecto | Tiempo esperado | Frecuencia de verificación |
|---------------------|-----------------|---------------------------|
| < 1000 líneas | 2-3 minutos | Cada 2 minutos |
| 1000-5000 líneas | 5-8 minutos | Cada 3 minutos |
| 5000-10000 líneas | 8-15 minutos | Cada 5 minutos |
| > 10000 líneas | 15-30 minutos | Cada 10 minutos |

**Si excede el tiempo esperado + 50%:** Considerar que los agentes fallaron.

---

## Re-lanzamiento de Agentes

Si los agentes fallaron, las opciones son:

1. **Re-lanzar los mismos agentes** — Si el fallo fue temporal
2. **Auditoría manual directa** — Si el framework de delegación está inestable
3. **Dividir el proyecto** — Si es muy grande, auditar por módulos

**Regla:** Si los agentes fallan 2 veces consecutivas, usar auditoría manual.
