# Monitoreo Proactivo de Subagentes — Guía de Campo

> **Lección aprendida:** Sesión 2026-06-26 con Robotito RAG Chatbot. Los subagentes de auditoría fallaron silenciosamente, requiriendo monitoreo proactivo y recuperación manual.

---

## Contexto

Durante la auditoría del proyecto Robotito (7500 líneas, rama `feature/rag-industrial-robustness`), los subagentes de `delegate_task` fallaron de múltiples formas:

1. **Primera auditoría:** Agentes modificaron archivos (violación READ-ONLY)
2. **Segunda auditoría:** 2 de 3 agentes completaron, 1 no retornó
3. **Tercera auditoría:** 3 agentes reportaron "dispatched" pero nunca iniciaron (sin procesos, sin logs)
4. **Ejecución de plan:** 1 agente completó, 1 falló silenciosamente

---

## Señales de Fallo Silencioso

| Síntoma | Diagnóstico | Tiempo de detección |
|---------|-------------|---------------------|
| `process(action='list')` vacío después de 5 min | Agentes no iniciaron | 5 min |
| Sin registros en `~/.hermes/logs/agent.log` | Delegación falló completamente | 5 min |
| Sin archivos nuevos/modificados en el proyecto | Agentes no ejecutaron | 5-10 min |
| Agente no retorna después de 15 min | Timeout o loop infinito | 15 min |
| Errores de regex en logs del agente | Agente falló parcialmente | Variable |

---

## Protocolo de Monitoreo

### Frecuencia por tamaño de proyecto

```
> 5000 líneas:  Cada 2-3 minutos
2000-5000:     Cada 5 minutos
< 2000:        Al finalizar, verificar una vez
```

### Comandos de verificación (ejecutar en secuencia)

```bash
# 1. Procesos activos
process(action='list')

# 2. Logs de delegación (reemplazar <delegation_id> con el ID real)
grep -E "deleg_<id>" ~/.hermes/logs/agent.log | tail -20

# 3. Timestamps de archivos (detectar modificaciones no autorizadas)
cd <project_dir> && find . -name "*.py" -mmin -10 | head -10

# 4. Archivos nuevos creados
find . -type f -mmin -10 | grep -v __pycache__ | grep -v .git | grep -v .pytest_cache
```

### Matriz de decisión

| Procesos | Logs | Archivos | Acción |
|----------|------|----------|--------|
| ✅ Activos | ✅ Registros | ✅ Sin cambios | Continuar monitoreo |
| ❌ Vacío | ❌ Sin registros | ❌ Sin cambios | **Delegación falló. Usar auditoría manual.** |
| ❌ Vacío | ✅ Registros | ❌ Sin cambios | Agente falló al iniciar. Re-lanzar una vez. |
| ✅ Activos | ✅ Errores | ❌ Sin cambios | Agente falló parcialmente. Evaluar si continuar. |
| ❌ Vacío | ❌ Sin registros | ✅ Modificados | **Agente inició pero falló. Revisar qué modificó.** |

---

## Recuperación

### Primera falla (reintentar)

```python
delegate_task(
    goal="...",
    context="... (más específico)",
    role="leaf",
    toolsets=["terminal", "file", "coding"]
)
```

### Segunda falla (auditoría manual)

**NO re-lanzar más de 2 veces.** Proceder con:

1. **Reconocimiento** (igual que Fase 1 del skill)
2. **Análisis por patrones** con `search_files`
3. **Análisis de archivos críticos** con `read_file` (secciones, no completos)
4. **Consolidación** del reporte

### Verificación post-recuperación

```bash
# Siempre verificar integridad después de fallo
cd <project_dir> && git status --short
# o si no hay Git:
cd <project_dir> && find . -name "*.py" -mmin -30 | head -20
```

---

## Lecciones Aprendidas

### 1. No confiar en "dispatched" como garantía de ejecución

`delegate_task` puede reportar "dispatched" exitosamente pero los agentes nunca inician. Siempre verificar con `process(action='list')`.

### 2. Verificar path antes de delegar

Los agentes pueden confundirse de path si el contexto incluye información incorrecta. Usar siempre paths absolutos verificados con `pwd`.

### 3. Monitoreo proactivo > reactivo

Esperar a que el usuario pregunte "¿cómo van los agentes?" es tarde. El usuario prefiere monitoreo proactivo, especialmente en proyectos grandes.

### 4. Auditoría manual como primera opción de fallback

Si los agentes fallan 2 veces, no insistir con un tercer intento. El framework de delegación tiene problemas persistentes que no se resuelven reintentando.

### 5. Documentar fallos para futuras sesiones

Cada fallo de subagentes debe documentarse para mejorar el skill y prevenir recurrencia.

---

## Referencias

- SKILL.md principal: `bug-slayer` — Fase 3.2 (Monitoreo Proactivo)
- Referencia relacionada: `references/audit-without-git.md`
- Template: `templates/zero-bugs-report.md`
