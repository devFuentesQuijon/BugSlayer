# Changelog — Bug Slayer

## [1.1.0] — 2026-07-01

### Added
- Pre-flight check de delegación (Fase 0.3).
- Agente verificador de hallazgos (Agente 4).
- Matriz de decisión: agentes vs auditoría manual (Fase 2.1).
- Auditoría manual directa como opción principal para proyectos >5000 líneas (Fase 2.4).
- Criterios de exclusión y formato obligatorio en prompts de los 3 agentes de auditoría.
- Referencia `verifying-bug-slayer-findings.md` para validación de hallazgos.

### Changed
- Prompts de agentes 1, 2 y 3 ahora exigen evidencia y reducen falsos positivos.
- Pitfalls actualizados para reflejar fallo silencioso y preferencia por manual en proyectos grandes.
- Numeración de fases corregida (auditoría manual ahora es Fase 2.4, verificación de hallazgos Fase 3.3).

### Fixed
- Secciones numeradas inconsistentes entre auditoría manual y fase de verificación.

---

## [1.0.0] — Versión inicial

- 7 fases de Bug Slayer.
- 3 agentes de auditoría en paralelo.
- Fases de exterminación, verificación y prevención.
