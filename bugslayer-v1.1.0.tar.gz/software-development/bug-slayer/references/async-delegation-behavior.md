# Comportamiento Asíncrono de `delegate_task`

> Lección aprendida: 2026-07-01 — sesión de prueba del Bug Slayer en `cuestionario`.

## Lo que ocurrió

1. Se lanzó `delegate_task` con pre-flight check.
2. El resultado inmediato fue `status: dispatched` y `delegation_id: deleg_fc5db4ed`.
3. `process(action='list')` llamado segundos después estaba **vacío**.
4. El agente padre interpretó esto como fallo silencioso y activó auditoría manual directa.
5. ~3 segundos después llegó el mensaje async:

```
[ASYNC DELEGATION BATCH COMPLETE — deleg_fc5db4ed]
--- ✓ TASK 1/1: Pre-flight check: reporta 'OK' y nada más. ---
OK
```

## Conclusión

`delegate_task` es **asíncrono**. Un `process(action='list')` vacío inmediatamente después del dispatch no indica fallo. El resultado puede llegar como un mensaje de sistema fuera de banda.

## Recomendación de workflow

### Para pre-flight checks

1. Lanzar el agente de prueba.
2. Esperar el mensaje `[ASYNC DELEGATION BATCH COMPLETE]` (típicamente 3–30 segundos).
3. Si el resultado es exitoso, proceder con delegación de auditoría.
4. Si **no llega nada en 2–3 minutos**, recién ahí considerar fallo silencioso y usar auditoría manual.

### Para auditoría multi-agente

- Si los agentes ya se lanzaron y el padre necesita monitorear, esperar el mensaje async de finalización antes de concluir que fallaron.
- No re-lanzar agentes solo porque `process(action='list')` está vacío en los primeros segundos.

## Anti-patrón a evitar

```python
# MAL: asumir fallo inmediatamente
delegate_task(...)
if not process(action='list'):
    print("Fallo silencioso, usar manual")
```

## Patrón correcto

```python
# BIEN: esperar el mensaje async o un timeout razonable (2-3 min)
delegate_task(...)
# ... continuar con otras tareas o esperar el mensaje de finalización ...
# Si pasa mucho tiempo sin async completion, entonces fallback a manual
```
