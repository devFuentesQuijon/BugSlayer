# Metodología Bug Slayer — Framework Agnóstica

> **Misión: Encontrar y eliminar todos los bugs hasta dejar cero.**
> **Core principle:** No se detiene hasta que el proyecto está limpio.

---

## Filosofía

### El Mantra del Bug Slayer

```
NO PARA HASTA QUE NO QUEDE NINGUNO
PREPARAR → AUDITAR → ENCONTRAR → CORREGIR → VERIFICAR → REPETIR
```

### Principios Inquebrantables

1. **Cero bugs como objetivo innegociable**: No se entrega el proyecto hasta confirmar cero bugs.
2. **Auditoría read-only**: Durante la fase de descubrimiento solo se inspecciona código; no se modifica ni ejecuta nada riesgoso en producción.
3. **Deduplicación inteligente**: Si múltiples fuentes reportan el mismo bug, se consolida un solo hallazgo con la evidencia más detallada.
4. **Verificación antes de corrección**: Todo hallazgo debe confirmarse leyendo el código exacto antes de aplicar un fix.
5. **Prevención de recurrencia**: Todo bug crítico/alto debe contar con una prueba que impida su regreso.
6. **Control de cambios primero**: Nunca auditar sin respaldo; sin rollback no hay auditoría segura.
7. **Manual como fallback**: Si la orquestación automática falla dos veces, continuar con ejecución manual directa.

---

## Cuándo Usar

- Auditoría completa + corrección de un proyecto
- Antes de un release, migración crítica o despliegue
- Después de incidentes en producción
- Al heredar un proyecto desconocido
- Cuando se necesita un baseline de calidad

**No usar para**: features nuevas, revisiones puntuales de PR, debugging completamente aislado sin alcance.

---

## Matriz de Severidad

| Severidad | Definición | Tiempo de Respuesta | Ejemplos |
|-----------|------------|---------------------|----------|
| **CRÍTICO** | Caída, seguridad, pérdida de datos | Inmediato | SQL injection, deadlock en transacción, null pointer en producción |
| **ALTO** | Funcionalidad rota, rendimiento inaceptable | Esta semana | N+1 queries, algoritmo incorrecto, API errónea |
| **MEDIO** | Edge case, deuda técnica, workaround | Este mes | Falta validación opcional, código duplicado, manejo silencioso de errores |
| **BAJO** | Mejora incremental, code smell | Backlog | Nombre poco claro, falta type hints, comentario obsoleto |

---

## Roles de Auditoría

Reemplazar “agente” por el rol, herramienta o flujo que use tu stack.

### Rol 1 — Cazador de Bugs Críticos (Seguridad + Estabilidad)

Enfoque:
- Seguridad: secretos hardcodeados, inyección, path traversal, eval/exec con input de usuario, deserialización insegura, autenticación débil.
- Estabilidad: race conditions, deadlocks, memory leaks, divisiones por cero, loops infinitos, recursión sin base case.
- Integridad: transacciones sin commit/rollback, operaciones no atómicas, validación de entrada faltante.
- Configuración: secretos en ejemplos/env, passwords por defecto inseguros, variables sin validación.

Reglas de calibración:
- Si existe sanitización/escape, no reportar inyección a menos que haya un bypass.
- Si una operación crítica tiene lock/semáforo, no reportar race condition.

Salida esperada por hallazgo:
- severidad, archivo, línea, evidencia, impacto, reproducción, solución sugerida.

### Rol 2 — Cazador de Bugs Funcionales (Lógica + APIs + Integraciones)

Enfoque:
- Lógica de negocio: cálculos incorrectos, edge cases, state machines inválidos, complejidad algorítmica.
- APIs: validación request/response, métodos HTTP, status codes, manejo de errores HTTP.
- Integraciones: timeouts, reintentos sin backoff, manejo de errores de APIs externas, webhooks sin verificación.
- Flujo de datos: transformaciones incorrectas, pérdida de datos, encoding/decoding, serialización inconsistente.
- RAG: prompt injection, retrieval sin umbral, None sin manejo, contexto expuesto.

Reglas de calibración:
- Si hay validación por schemas/tipos/excepciones, no reportar “falta validación” a menos que sea incompleta.
- Si hay retry con backoff, no reportar “reintentos sin backoff”.

Salida esperada por hallazgo:
- severidad, archivo, función, línea, comportamiento esperado, comportamiento actual, caso mínimo de reproducción, solución sugerida.

### Rol 3 — Cazador de Bugs de Calidad (Arquitectura + Rendimiento + Deuda Técnica)

Enfoque:
- Arquitectura: acoplamiento fuerte, violación de SRP, dependencias circulares, funciones monolíticas.
- Rendimiento: N+1, falta de caching, algoritmos O(n²) donde debería ser O(n), memory leaks.
- Deuda técnica: código duplicado crítico, magic numbers, comentarios obsoletos, funciones con múltiples responsabilidades.
- Observabilidad: logs sin estructura, métricas faltantes, trazado ausente, errores silenciosos.
- Deploy: imágenes grandes, secrets en imágenes, usuario root, builds sin stages.

Reglas de calibración:
- Solo reportar problemas con impacto real en 1-3 meses, no preferencias de estilo.
- Si hay tests que cubren una zona crítica, no reportar “cobertura baja” en esa zona.

Salida esperada por hallazgo:
- severidad, archivo/componente, impacto real, evidencia, refactor sugerido.

### Rol 4 — Verificador de Hallazgos (Opcional)

Enfoque:
- Confirmar si cada bug reportado es real, falso positivo, parcial o ya corregido.
- Justificar con evidencia de código exacta.

---

## Las 6 Fases

### Fase 0: Preparación

Objetivo: garantizar que el proyecto está listo para una auditoría segura.

Verificaciones:
- Control de versiones activo; si no existe, ofrecer inicializarlo o hacer backup antes de proceder.
- Working tree limpio o pendientes documentados.
- Backup existente o capacidad de rollback.

Regla: sin rollback, no hay auditoría segura.

---

### Fase 1: Reconocimiento

Objetivo: entender el alcance suficiente para planificar la auditoría.

Acciones:
- Mapear estructura del proyecto.
- Contar líneas de código por lenguaje.
- Identificar archivos de configuración y dependencias.
- Identificar tests existentes.
- Leer solo archivos críticos: dependencias, configuración, README y 2-3 fuentes principales.

Regla: detenerse después de esta fase y no inspeccionar todo el código en el reconocimiento.

---

### Fase 2: Auditoría

#### Modos posibles

| Condición | Acción recomendada |
|-----------|-------------------|
| Proyecto pequeño, orquestación disponible | Ejecutar roles 1-3 en paralelo |
| Proyecto mediano/grande, orquestación disponible | Ejecutar en lotes o roles secuenciales con review parcial |
| Orquestación falla 2 veces | Auditoría manual directa |
| Proyecto muy grande | Auditoría manual directa desde esta fase |

#### Modo manual directo

Acciones:
- Buscar patrones de riesgo: excepciones silenciosas, input de usuario en eval/exec, secretos en texto plano, timeouts ausentes, logging inseguro, SQLite sin modo seguro, etc.
- Revisar archivos críticos en bloques, concentrándose en rutas de entrada, autenticación, manejo de errores y datos.
- Registrar hallazgos en borrador sin corregir nada.

Reglas:
- Todo hallazgo debe incluir: severidad, ubicación, evidencia, impacto, reproducción, remediación.
- No abusar de falsos positivos; calibrar severidad.
- No mezclar auditoría y corrección.

---

### Fase 3: Espera + Verificación

Objetivo: consolidar hallazgos sin adelantarse ni contaminar la auditoría.

Acciones:
- Integrar hallazgos deduplicando por archivo/línea.
- Reler el código exacto de cada hallazgo antes de declararlo válido.
- Clasificar: confirmado, falso positivo, parcial, ya corregido.
- Si hay herramientas automatizadas, ejecutarlas sobre el proyecto ahora.
- Verificar que no haya cambios no autorizados en archivos.

Regla: no continuar con fases siguientes hasta tener un reporte consolidado verificado.

---

### Fase 4: Consolidación del Reporte

Objetivo: generar un reporte accionable y priorizado.

Estructura esperada:
- Resumen ejecutivo.
- Hallazgos por severidad: críticos, altos, medios, bajos.
- Tabla de métricas del proyecto.
- Recomendaciones de prevención opcionales.

Criterios:
- Prioridad descendente por severidad.
- Cada hallazgo trazable a código exacto.
- Sin ruido ni smells repetidos; uno por patrón real.

---

### Fase 5: Corrección

Objetivo: eliminar bugs confirmados manteniendo calidad.

Reglas:
- Orden obligatorio: crítico → alto → medio → bajo.
- Un cambio a la vez; registrar cada modificación.
- Parchear solo después de haber leído y confirmado el bloque exacto.
- Si una herramienta de aplicación de cambios falla dos veces, reintentar manualmente.
- Por cada bug crítico/alto, agregar una prueba de regresión.
- Ejecutar suite de verificación después de cada lote de severidad.

Patrón de ciclo por bug:
1. Marcar en progreso.
2. Confirmar evidencia en código.
3. Aplicar cambio mínimo y atómico.
4. Ejecutar prueba o linter/configuración equivalente.
5. Marcar como completado.

---

### Fase 6: Verificación de Cero Bugs

Objetivo: confirmar que el proyecto quedó limpio y que los fixes no introdujeron nuevos problemas.

Verificaciones:
- Re-ejecutar la auditoría en modo verificación, o repetir roles 1-3.
- Ejecutar pruebas, lint, tipos, estática y métricas equivalentes.
- Revisar cambios con diff para eliminar código temporal/debug.
- Si hay despliegue activo, comparar versión desplegada con código corregido.

Reporte final esperado:
- Estado CERO BUGS.
- Tabla antes/después por severidad.
- Lista de tests de regresión agregados.
- Lista de archivos modificados.
- Métricas post-exterminio.

---

## Formatos de Reporte

### Hallazgo de auditoría

```
SEVERIDAD: CRÍTICO | ALTO | MEDIO | BAJO
ARCHIVO: ruta:línea o ruta:componente
EVIDENCIA: cita exacta
IMPACTO: qué puede pasar si se explota o se mantiene
REPRODUCCIÓN: pasos mínimos
SOLUCIÓN: descripción o pseudocódigo, sin aplicar
```

### Reporte consolidado

```
# REPORTE BUG SLAYER — Nombre del Proyecto

## Resumen Ejecutivo
- Total de bugs encontrados: X
- Críticos: X | Altos: X | Medios: X | Bajos: X

## 🔴 CRÍTICOS
| ID | Archivo | Línea | Descripción | Solución |

## 🟠 ALTOS
## 🟡 MEDIOS
## 🟢 BAJOS

## Métricas del Proyecto
| Métrica | Valor |
```

### Reporte final

```
# REPORTE BUG SLAYER — FASE COMPLETADA
## Estado: CERO BUGS ALCANZADO

| Severidad | Cantidad | Estado |
| Crítico | X | ✅ Eliminados |
| Alto | X | ✅ Eliminados |
| Medio | X | ✅ Eliminados |
| Bajo | X | ✅ Eliminados |
| Total | X | ✅ CERO |

### Tests de Regresión Creados
### Archivos Modificados
### Métricas de Calidad Post-Exterminio
```

---

## Cómo Ejecutar Esto en Otro Stack

### Caso A: Orquestación automática disponible

1. Mapear cada rol a una herramienta, agente, job o prompt separado del framework destino.
2. Ejecutar los tres roles principales en paralelo o secuencialmente según capacidad.
3. Recoger resultados del framework y deduplicar por ruta/línea.
4. Ejecutar fase 3 manualmente sobre el resultado.

### Caso B: Sin orquestación / falla de orquestación

1. Ejecutar reconocimiento.
2. Aplicar auditoría manual directa con la checklist de cada rol.
3. Consolidar y verificar antes de corregir.

### Caso C: Mixto

1. Ejecutar rol 1 automáticamente o manualmente.
2. Ejecutar roles 2 y 3 en batches según tamaño del proyecto.
3. Seguir con fases 3 a 6 sin orquestación compleja.

---

## Troubleshooting General

- **Demasiados falsos positivos**: endurecer las reglas de calibración; no reportar bugs sin evidencia de código.
- **No se puede deduplicar**: unificar criterios por ruta y línea antes de consolidar.
- **Cambios no autorizados después de la auditoría**: detener todo y revertir; la auditoría es read-only.
- **Falla de orquestación dos veces**: cambiar a manual directo sin reintentar indefinidamente.
- **Proyecto sin respaldo**: detener y ofrecer inicializar control de versiones o backup antes de continuar.
- **Deploy activo desfasado**: verificar que la versión ejecutada refleje el código corregido antes de declarar éxito.

---

## Licencia

MIT — Hermes Agent © Nous Research