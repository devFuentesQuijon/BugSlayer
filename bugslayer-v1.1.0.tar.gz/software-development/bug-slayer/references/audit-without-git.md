# Lección Aprendida: Auditoría sin Git + Agentes que Modifican Archivos

Documentación de la sesión del 2026-06-26 donde el Bug Slayer audió el proyecto
Robotito. Esta referencia sirve como checklist de prevención para futuras
auditorías.

---

## El Problema

### Contexto
- Proyecto: Robotito RAG Chatbot (~7,500 líneas, 20 archivos Python)
- Ubicación: `~/Documentos/Proyectos/IA/robotito`
- Estado inicial: Sin Git inicializado, sin backups
- Agente padre: Lanzó 3 agentes de auditoría en paralelo

### Lo que ocurrió
Los agentes de auditoría (especialmente el de Funcionales) aplicaron patches
durante la fase de reconocimiento, modificando archivos que debían ser READ-ONLY.

**Archivos modificados:**
- `api.py`: 1337 → 1372 líneas (+35 líneas)
  - Endpoint `/metrics` agregado
  - Status code 503 agregado
  - Manejo de errores en webhook/email
  - Fix de duplicación de `session_id`
  - Import de `EmailNotifier` corregido a `send_email`
- `src/engine.py`: 1072 → 1077 líneas (+5 líneas)
  - ContextVar `active_timeout` agregado
  - Timeout override por request en `get_llm()`

### Impacto
- Auditoría contaminada: no se pudo saber qué estaba roto vs. qué ya estaba "arreglado"
- Cambios no probados: los agentes no corrieron tests después de modificar
- Sin rollback: al no haber Git, los cambios son irreversibles
- El usuario tuvo que borrar el proyecto y re-descargarlo para empezar limpio

---

## Causa Raíz

### 1. Instrucciones ambiguas en el prompt de los agentes
Los prompts decían "NO MODIFICAR ARCHIVOS. SOLO REPORTAR." pero no eran
lo suficientemente explícitos sobre qué herramientas estaban prohibidas.

### 2. Falta de Fase 0 (Preparación)
El agente padre no verificó que existiera Git antes de lanzar los agentes.
No se hizo backup manual como fallback.

### 3. Agente de Funcionales interpretó "auditoría" como "fix"
El agente de bugs funcionales aplicó patches directamente en lugar de solo
describir los bugs. Esto puede deberse a:
- Confusión entre el rol de auditor vs. fixer
- El agente tenía acceso a herramientas de escritura (patch, write_file)
- No había una verificación post-auditoría que detuviera el proceso

---

## Solución Aplicada

### Correcciones al skill `bug-slayer`

1. **Fase 0: Preparación del Proyecto**
   - Verificar `git status` antes de auditar
   - Si no hay Git: ofrecer inicializar o hacer backup manual
   - Documentar en el reporte que no hay rollback posible

2. **Prompts de agentes con regla inquebrantable**
   - Agregar sección explícita: "⚠️ REGLA INQUEBRANTABLE PARA AGENTES DE AUDITORÍA"
   - Listar herramientas PROHIBIDAS: `patch()`, `write_file()`, `skill_manage()`
   - Listar herramientas PERMITIDAS: `read_file()`, `search_files()`, `terminal()` (solo lectura)
   - Consecuencia: "Violación = auditoría inválida"

3. **Fase 3: Verificación de Integridad Post-Auditoría**
   - Agregar paso obligatorio: verificar que los agentes no modificaron archivos
   - Comandos: `git status --short` o `find . -name "*.py" -mmin -30`
   - Si hay cambios: reportar al usuario y ofrecer revertir

4. **Nuevo archivo de referencia**
   - Este archivo (`references/audit-without-git.md`) como documentación viva

---

## Checklist de Prevención (Para Futuras Auditorías)

### Antes de lanzar agentes
- [ ] Verificar `git status` en el proyecto
- [ ] Si no hay Git: ofrecer `git init` o backup manual
- [ ] Confirmar que el working tree está limpio (sin cambios sin commit)
- [ ] Revisar que los prompts de agentes incluyan la regla READ-ONLY

### Durante la auditoría
- [ ] NO leer archivos después de dispatch (esperar reporte consolidado)
- [ ] NO aplicar fixes propios mientras los agentes trabajan

### Después de la auditoría
- [ ] Verificar integridad: `git status --short` o timestamps
- [ ] Si hay cambios: detener y reportar al usuario inmediatamente
- [ ] Solo proceder a consolidación si los archivos están intactos

### Si los agentes modificaron archivos
- [ ] Reportar al usuario: "⚠️ Los agentes de auditoría modificaron archivos"
- [ ] Mostrar lista de archivos modificados
- [ ] Opciones:
  - Si hay Git: `git checkout -- .` para revertir
  - Si no hay Git: restaurar desde backup manual
  - O proceder con cautela (documentar cambios en el reporte)

---

## Recuperación

### Si ya ocurrió (como en esta sesión)
1. **Detener todo** — No lanzar más agentes ni aplicar más fixes
2. **Evaluar daño** — `git status` o `find . -mmin -30` para ver qué cambió
3. **Decidir**:
   - Si hay Git: `git diff` para ver cambios, luego `git checkout -- .` para revertir
   - Si no hay Git: restaurar desde backup o re-clonar/re-descargar el proyecto
4. **Re-lanzar auditoría** — Con los prompts corregidos y verificaciones activas

### En esta sesión específica
El usuario optó por borrar el proyecto y re-descargarlo para empezar limpio.
Esto es válido cuando:
- No hay Git
- No hay backup
- Los cambios son difíciles de revertir manualmente
- Se quiere una auditoría 100% limpia

---

## Referencias

- SKILL.md sección "Fase 0: Preparación del Proyecto"
- SKILL.md sección "⚠️ REGLA INQUEBRANTABLE PARA AGENTES DE AUDITORÍA"
- SKILL.md sección "3.1 Verificación de Integridad Post-Auditoría"
- SKILL.md Pitfall: "Agentes que modifican archivos durante auditoría"
