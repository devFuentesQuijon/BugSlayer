# Lecciones Aprendidas — Sesión 26 de Junio de 2026

## Contexto

Proyecto: Robotito RAG Chatbot (UCSH)
Path: `/home/david/Documentos/Proyectos/IA/robotito`
Rama: `feature/rag-industrial-robustness`

## Lecciones de Subagentes

### 1. Subagentes de Auditoría Fallan Silenciosamente

**Problema:** 3 de 3 subagentes de auditoría fallaron en la primera pasada. 2 de 3 fallaron en la segunda pasada. Los agentes reportaban "dispatched" pero nunca aparecían en `process(action='list')` ni en los logs.

**Causa raíz:** El framework de delegación tiene problemas persistentes con proyectos grandes (>7500 líneas, 21 archivos Python). Los agentes se confunden de directorio, usan regex inválidas, o simplemente no inician.

**Solución:** Implementar auditoría manual directa como fallback después de 2 fallas. Ver `references/agent-monitoring-proactive.md`.

**Resultado:** Auditoría manual encontró 35 bugs (10 CRÍTICOS + 14 ALTOS + 8 MEDIOS + 3 BAJOS).

### 2. Subagentes de Implementación También Fallan

**Problema:** Subagentes de implementación (Fase 1.3, Fase 2.1, Fase 2.2) también fallaron silenciosamente. El usuario tuvo que decir "Implementa manualmente ahora" después de múltiples fallas.

**Causa raíz:** Mismo problema que los agentes de auditoría — el framework de delegación no es confiable para tareas complejas.

**Solución:** Implementación manual directa como fallback inmediato. No re-lanzar subagentes más de 1 vez para implementación.

**Resultado:** Implementación manual completó 25 bugs en 3 fases (Fase 1: Infraestructura, Fase 2: Separación de Responsabilidades).

### 3. Lazy Loading para Variables de Entorno

**Problema:** `crypto_utils.py` validaba `ENCRYPTION_MASTER_KEY` al importar el módulo, causando que los tests fallaran si no había env vars configuradas.

**Solución:** Implementar lazy loading con `get_settings()` que valida la clave solo cuando se usa, no al importar. Usar try/except al importar para permitir importación sin env vars en desarrollo.

```python
# crypto_utils.py
try:
    settings = _load_settings()
except ValueError:
    settings = None  # Allow import without valid key for development/testing

def get_settings():
    global settings
    if settings is None:
        settings = _load_settings()
    return settings
```

### 4. Paths Incorrectos en Subagentes

**Problema:** Un subagente usó `robotito/robotito-main/` en lugar de `robotito/`. Otro usó regex inválida con `\n` literal.

**Solución:** Siempre confirmar path real con `pwd` o `ls` antes de proporcionarlo a subagentes. Usar paths absolutos en el contexto de `delegate_task`.

### 5. Monitoreo Proactivo Obligatorio

**Problema:** Subagentes fallaban sin notificación. El usuario tenía que preguntar "¿Qué pasó con el agente X?"

**Solución:** Monitoreo proactivo cada 2-3 minutos para proyectos >5000 líneas. Verificar `process(action='list')`, timestamps de archivos, y logs. Ver `references/agent-monitoring-proactive.md`.

## Métricas de la Sesión

| Fase | Bugs Corregidos | Tests Nuevos | Tests Totales |
|------|-----------------|--------------|---------------|
| Fase 1: Infraestructura | 3 (H7, H9, H10) | 101 | 101 |
| Fase 2: Separación de Responsabilidades | 3 (C2, H1, H2) | 15 | 116 |
| **Total** | **6** | **116** | **116** |

## Archivos Creados/Modificados

| Archivo | Tipo | Descripción |
|---------|------|-------------|
| `src/config.py` | Nuevo | Configuración centralizada Pydantic BaseSettings |
| `src/constants.py` | Nuevo | Constantes y enums centralizados |
| `src/crypto_utils.py` | Modificado | ENCRYPTION_MASTER_KEY obligatoria, lazy loading |
| `src/db.py` | Nuevo | DatabaseManager extraído de api.py |
| `src/rag_service.py` | Nuevo | Servicio RAG compartido (singleton) |
| `api.py` | Modificado | Usa get_rag_service() en lugar de estado global |
| `app.py` | Modificado | Usa get_rag_service() en get_rag_engine() |
| `src/telegram_bot.py` | Modificado | Usa get_rag_service() para inicialización |
| `src/eval_ragas.py` | Modificado | Usa get_rag_service() para evaluación |
| `tests/test_config.py` | Nuevo | 24 tests de configuración |
| `tests/test_constants.py` | Nuevo | 63 tests de constantes |
| `tests/test_crypto_utils.py` | Nuevo | 14 tests de crypto |
| `tests/test_db.py` | Nuevo | 15 tests de DatabaseManager |

## Bugs Pendientes

| Severidad | Cantidad | IDs |
|-----------|----------|-----|
| CRÍTICO | 2 | C1, C8 |
| ALTO | 5 | H3, H4, H5, H6, H14 |
| MEDIO | 6 | M1, M2, M3, M4, M6 |
| BAJO | 1 | L3 |
| **Total** | **14** | — |

## Preferencias del Usuario Confirmadas

1. **Secuencial sobre paralelo:** Esperar que termine cada fase antes de continuar
2. **Monitoreo activo:** Verificar progreso de subagentes, no fire-and-forget
3. **Implementación manual como fallback:** Cuando subagentes fallan, proceder manualmente inmediatamente
4. **Cero bugs:** Corregir TODOS los bugs (critical → high → medium → low)
5. **Español:** Todo el proyecto y comunicación en español

## Recomendaciones para Futuras Sesiones

1. **No usar subagentes para implementación** en este proyecto. Implementar manualmente desde el inicio.
2. **Verificar estado del proyecto** con `git status` antes de cada fase.
3. **Mantener TODO list actualizado** después de cada fix.
4. **Correr tests después de cada batch** de severidad.
5. **Hacer commit después de cada fase** para tener puntos de rollback.

## Nuevas Lecciones de Implementación Manual

### 6. Cookie Security en Streamlit

**Problema:** `extra_streamlit_components.CookieManager` no soporta atributos de seguridad (`HttpOnly`, `Secure`, `SameSite`).

**Solución:** Implementar función helper que inyecta JavaScript para establecer cookies con atributos de seguridad:

```python
def set_secure_cookie(cookie_manager, name, value, expires_at=None, max_age_days=1):
    """Set cookie with security attributes via JavaScript injection."""
    # Set via CookieManager for compatibility
    cookie_manager.set(name, value, expires_at=expires_at)
    
    # Inject JavaScript for security attributes
    secure_cookie_js = f"""
    <script>
    (function() {{
        var expires = new Date();
        expires.setDate(expires.getDate() + {max_age_days});
        document.cookie = "{name}=" + encodeURIComponent("{value}") + 
            "; expires=" + expires.toUTCString() + 
            "; path=/" + 
            "; SameSite=Strict" + 
            "; Secure";
    }})();
    </script>
    """
    st.markdown(secure_cookie_js, unsafe_allow_html=True)
```

### 7. Async Lock para Inicialización RAG

**Problema:** `check_and_reload_engine()` usaba booleano `is_loading` para prevenir concurrencia, pero no era thread-safe.

**Solución:** Reemplazar booleano por `asyncio.Lock()`:

```python
import asyncio

_reload_lock = asyncio.Lock()

async def check_and_reload_engine():
    if _reload_lock.locked():
        return  # Already initializing
    
    async with _reload_lock:
        # Safe initialization code here
        pass
```

**Importante:** Convertir todas las llamadas a `await check_and_reload_engine()` y hacer la función async.

### 8. Rate Limiting en Streamlit Login

**Problema:** Login de Streamlit sin protección contra fuerza bruta.

**Solución:** Implementar contador de intentos fallidos en `st.session_state`:

```python
# Initialize rate limiting state
if "login_attempts" not in st.session_state:
    st.session_state.login_attempts = 0
if "login_locked_until" not in st.session_state:
    st.session_state.login_locked_until = None

# Check lockout
if st.session_state.login_locked_until:
    if datetime.now() < st.session_state.login_locked_until:
        st.error(f"Locked. Wait {(st.session_state.login_locked_until - datetime.now()).seconds // 60} minutes.")
        return

# On failed login
st.session_state.login_attempts += 1
if st.session_state.login_attempts >= MAX_ATTEMPTS:
    st.session_state.login_locked_until = datetime.now() + timedelta(minutes=LOCKOUT_MINUTES)
```

### 9. Patrón de Fallo Silencioso de Subagentes

**Problema:** `delegate_task` reporta "dispatched" pero agentes no aparecen en `process(action='list')` ni hay logs.

**Señales:**
- `process(action='list')` vacío después de 2-3 minutos
- No hay archivos nuevos (`find . -mmin -5`)
- No hay registros en `~/.hermes/logs/agent.log`

**Acción inmediata:** Asumir fallo silencioso y proceder con implementación manual. No esperar más de 3 minutos para verificar.

**Preferencia del usuario:** Cuando se ofrecen opciones después de fallos de subagentes, el usuario prefiere implementación manual (opción 2) sobre re-lanzar subagentes.
