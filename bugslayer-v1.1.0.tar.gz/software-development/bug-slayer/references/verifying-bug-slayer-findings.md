# Verificación de Hallazgos del Bug Slayer

> Antes de crear TODOs y corregir, validar cada hallazgo.

## Proceso

1. Leer el código exacto referenciado por el agente.
2. Clasificar cada hallazgo:
   - `CONFIRMADO`: El bug existe y está activo.
   - `FALSO POSITIVO`: El código ya mitiga el problema o la interpretación es incorrecta.
   - `PARCIAL`: El bug existe pero con impacto menor o condición más específica.
   - `YA CORREGIDO`: El bug fue arreglado en una fase anterior.
3. Documentar la clasificación junto al reporte.
4. Solo crear TODOs para hallazgos `CONFIRMADO` o `PARCIAL` con severidad ajustada.

## Patrones comunes de falsos positivos

- Race condition ya protegida por Lock.
- Validación realizada por Pydantic/BaseSettings.
- Excepción con `pass` en tests o stubs intencionales.
- `except Exception` con logging adecuado.
- Variables de entorno con default en desarrollo pero validadas en producción.

## Template de notas

```markdown
| ID | Agente | Archivo | Clasificación | Notas |
|----|--------|---------|---------------|-------|
| C1 | 1 | src/api.py:45 | CONFIRMADO | SQL injection real en query string |
| H3 | 2 | src/cache.py:22 | FALSO POSITIVO | Ya usa TTL correctamente |
```

## Regla de oro

Si un agente reporta más de 3 hallazgos sin evidencia de código, marcar los sin evidencia como `FALSO POSITIVO` y pedir al agente que los rehaga con el formato obligatorio.
