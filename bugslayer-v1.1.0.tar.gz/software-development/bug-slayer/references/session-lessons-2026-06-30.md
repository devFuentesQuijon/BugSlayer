---
title: "Bug Slayer: Lecciones de la sesión del 30 de junio de 2026"
date: 2026-06-30
skill: bug-slayer
---

# Lecciones de la sesión del 30 de junio de 2026

Contexto: continuación del exterminio de bugs en el proyecto Robotito (RAG Chatbot para UCSH), rama `feature/rag-industrial-robustness`. Fase 4 (Caché y Rendimiento) ejecutada manualmente.

## 1. Subagentes reportan "dispatch exitoso" pero no inician procesos

- `delegate_task` puede retornar un ID de delegación aparentemente exitoso.
- `process(action='list')` puede estar vacío inmediatamente después.
- No esperar a que aparezcan: si no hay procesos ni logs después de 1-2 minutos, asumir fallo silencioso y cambiar a implementación manual.
- El usuario confirmó preferencia por implementación manual cuando los subagentes fallan.

## 2. Herramientas destructivas y de ejecución arbitraria requieren consentimiento explícito

- `execute_code` fue bloqueado por falta de consentimiento del usuario.
- `terminal` con comandos destructivos (`rm`) fue bloqueado por falta de consentimiento.
- Lección: pedir confirmación antes de ejecutar acciones destructivas o scripts de debug. Preferir `terminal` con comandos de solo lectura para investigación.
- No usar `execute_code` para debugging si no se ha establecido confianza explícita con el usuario.

## 3. Tests con embeddings de dimensión 1 generan falsos positivos

- En `SemanticResponseCache`, vectores como `[1.0]`, `[2.0]`, `[3.0]` tienen similitud coseno de 1.0 entre sí.
- Esto invalida tests que intentan verificar evicción o hits semánticos con embeddings de 1D.
- Solución: usar vectores ortogonales de 3+ dimensiones en tests (por ejemplo, `[1,0,0]`, `[0,1,0]`, `[0,0,1]`).

## 4. Evicción LRU en cachés SQLite: ejecutar DESPUÉS del INSERT

- Si `_enforce_size_limit()` se ejecuta antes de insertar, el conteo nunca supera el límite y no se evicta nada.
- Orden correcto dentro de `set()`:
  1. `_cleanup_expired()`
  2. `INSERT`
  3. `_enforce_size_limit()`
  4. `COMMIT`
- Aplicar este patrón en cualquier caché SQLite con límite de tamaño.

## 5. Separar configuración pesada para permitir tests ligeros

- `src/engine.py` importa LlamaIndex completo, lo que hace que los tests de configuración fallen con `ModuleNotFoundError`.
- Solución: extraer `build_engine_config()` a un módulo independiente (`src/engine_config.py`) que no dependa de LlamaIndex.
- Esto permite testear la normalización de configuración sin inicializar el motor RAG.

## 6. Usar timestamps ISO de alta precisión para LRU en SQLite

- `CURRENT_TIMESTAMP` de SQLite tiene resolución de segundos, lo que puede causar ordenamiento no determinista en operaciones rápidas.
- Usar `datetime.now(timezone.utc).isoformat()` desde Python para obtener milisegundos y evitar empates en `accessed_at`.

## 7. Fase 4 y 5 completadas: resumen de cambios

- `EmbeddingCache`: TTL + límite de tamaño + LRU.
- `ResponseCache`: nuevo caché para respuestas LLM con TTL + límite.
- `cached_llm_complete`: helper para envolver llamadas a LLM con caché opcional.
- `SemanticResponseCache`: TTL + límite de tamaño + LRU.
- `build_engine_config()`: centralización de configuración del motor RAG.
- `src/analytics_utils.py`: helpers `safe_percentage` y `safe_divide` para evitar divisiones por cero en métricas.
- `api.py`: todos los `print()` de errores reemplazados por `logger.error()` / `logger.warning()`.
- Tests totales post-Fase 5: **146 passed**.
- Bugs pendientes: **4** (2 críticos, 2 altos).

## 8. Verificación de fases completadas: el usuario pide confirmación

- El usuario puede preguntar "¿está realizada la fase X?" antes de continuar.
- Responder con un resumen conciso: tests que pasan, tareas completadas y pendientes, y el siguiente paso propuesto.
- No detallar todo el historial; enfocarse en estado actual y decisión requerida.

## 9. Commit fase por fase con tests incluidos

- Al finalizar cada fase, el usuario eligió limpiar archivos temporales, commitear y continuar.
- Incluir en el mensaje de commit: qué fase, qué bugs se cierran, y el resultado de los tests.
- Esto deja un historial claro y permite revertir por fase si es necesario.
