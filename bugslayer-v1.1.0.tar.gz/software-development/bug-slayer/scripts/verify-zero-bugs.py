#!/usr/bin/env python3
"""
verify-zero-bugs.py

Script de verificación automatizada para confirmar que no quedan bugs
conocidos después de la fase de exterminación del Bug Slayer.

Uso:
    python verify-zero-bugs.py <project_dir> [--strict]

Exit codes:
    0 - Cero bugs encontrados (limpio)
    1 - Bugs encontrados (ver reporte)
"""

import argparse
import os
import re
import sys
from pathlib import Path
from typing import List, Dict, Tuple


class BugPattern:
    """Representa un patrón de bug conocido."""
    
    def __init__(
        self,
        id: str,
        name: str,
        severity: str,
        description: str,
        patterns: List[str],
        file_globs: List[str],
        exclude_dirs: List[str] = None,
        fix_hint: str = ""
    ):
        self.id = id
        self.name = name
        self.severity = severity
        self.description = description
        self.patterns = [re.compile(p, re.IGNORECASE) for p in patterns]
        self.file_globs = file_globs
        self.exclude_dirs = exclude_dirs or [".git", "node_modules", "venv", ".venv", "__pycache__", ".pytest_cache", "dist", "build"]
        self.fix_hint = fix_hint


# Catálogo de patrones de bugs conocidos
BUG_PATTERNS = [
    # === CRÍTICOS ===
    BugPattern(
        id="BS-CRIT-01",
        name="Secretos Hardcodeados",
        severity="CRÍTICO",
        description="API keys, tokens, o passwords hardcodeados en código fuente",
        patterns=[
            r"(api_key|apikey|secret|password|token|passwd)\s*=\s*['\"][^'\"]{8,}['\"]",
            r"(aws_access_key_id|aws_secret_access_key)\s*=\s*['\"]",
            r"sk-[a-zA-Z0-9]{20,}",  # OpenAI-style keys
            r"ghp_[a-zA-Z0-9]{36}",  # GitHub tokens
        ],
        file_globs=["*.py", "*.js", "*.ts", "*.go", "*.rs", "*.env", "*.yaml", "*.yml", "*.json"],
        fix_hint="Usar variables de entorno o gestor de secretos (Vault, AWS Secrets Manager)"
    ),
    BugPattern(
        id="BS-CRIT-02",
        name="Eval/Exec con Input de Usuario",
        severity="CRÍTICO",
        description="Uso de eval() o exec() con input potencialmente malicioso",
        patterns=[
            r"\beval\s*\(",
            r"\bexec\s*\(",
            r"subprocess\.\w+\s*\(.*shell\s*=\s*True",
            r"os\.system\s*\(",
        ],
        file_globs=["*.py"],
        fix_hint="Usar ast.literal_eval, subprocess.run([...]), o validación estricta"
    ),
    BugPattern(
        id="BS-CRIT-03",
        name="SQL Injection",
        severity="CRÍTICO",
        description="Concatenación de strings en queries SQL",
        patterns=[
            r"execute\s*\(\s*f[\"']",
            r"execute\s*\(\s*['\"].*%s",
            r"\.format\s*\(.*SELECT|\.format\s*\(.*INSERT",
            r"query\s*=\s*f[\"'].*SELECT",
        ],
        file_globs=["*.py", "*.js", "*.ts"],
        fix_hint="Usar parameterized queries con ? placeholders"
    ),
    BugPattern(
        id="BS-CRIT-04",
        name="Pickle Inseguro",
        severity="CRÍTICO",
        description="Deserialización con pickle puede ejecutar código arbitrario",
        patterns=[
            r"pickle\.loads?\s*\(",
            r"yaml\.load\s*\([^,]*\)",  # yaml.load sin Loader
        ],
        file_globs=["*.py"],
        fix_hint="Usar json, msgpack, o yaml.safe_load()"
    ),
    
    # === ALTOS ===
    BugPattern(
        id="BS-HIGH-01",
        name="Except Pass Silencioso",
        severity="ALTO",
        description="Excepciones que se tragan silenciosamente sin logging",
        patterns=[
            r"except\s*:\s*\n\s*pass",
            r"except\s+Exception\s*:\s*\n\s*pass",
            r"except\s*\(\s*\)\s*:\s*\n\s*pass",
        ],
        file_globs=["*.py"],
        fix_hint="Loggear el error con logger.exception() o re-raise"
    ),
    BugPattern(
        id="BS-HIGH-02",
        name="Request Sin Timeout",
        severity="ALTO",
        description="Requests HTTP sin timeout pueden colgar indefinidamente",
        patterns=[
            r"requests\.(get|post|put|delete)\s*\([^)]*\)(?!.*timeout)",
            r"urllib\.(urlopen|request)\s*\([^)]*\)(?!.*timeout)",
        ],
        file_globs=["*.py"],
        fix_hint="Agregar timeout= a todas las llamadas de red"
    ),
    BugPattern(
        id="BS-HIGH-03",
        name="Print en Producción",
        severity="ALTO",
        description="Uso de print() en lugar de logging estructurado",
        patterns=[
            r"\bprint\s*\(",
        ],
        file_globs=["*.py"],
        exclude_dirs=[".git", "node_modules", "venv", ".venv", "__pycache__", ".pytest_cache", "dist", "build", "scripts"],
        fix_hint="Reemplazar con logging.getLogger(__name__).info/debug/error()"
    ),
    BugPattern(
        id="BS-HIGH-04",
        name="SQLite Sin WAL",
        severity="ALTO",
        description="SQLite sin WAL mode causa database locked en concurrencia",
        patterns=[
            r"sqlite3\.connect\s*\([^)]*\)(?!.*PRAGMA.*journal_mode.*WAL)",
        ],
        file_globs=["*.py"],
        fix_hint="Agregar conn.execute('PRAGMA journal_mode=WAL') después de connect"
    ),
    BugPattern(
        id="BS-HIGH-05",
        name="Bucle Infinito Sin Límite",
        severity="ALTO",
        description="while True sin condición de salida o límite de reintentos",
        patterns=[
            r"while\s+True\s*:\s*\n\s*try",
            r"while\s+True\s*:\s*\n\s*except",
        ],
        file_globs=["*.py"],
        fix_hint="Agregar límite de reintentos con backoff exponencial"
    ),
    
    # === MEDIOS ===
    BugPattern(
        id="BS-MED-01",
        name="CORS Demasiado Permisivo",
        severity="MEDIO",
        description="CORS allow_methods/allow_headers con '*'",
        patterns=[
            r"allow_methods\s*=\s*\[\s*['\"]\\*['\"]",
            r"allow_headers\s*=\s*\[\s*['\"]\\*['\"]",
        ],
        file_globs=["*.py", "*.js", "*.ts"],
        fix_hint="Especificar métodos y headers exactos necesarios"
    ),
    BugPattern(
        id="BS-MED-02",
        name="Logging Mal Configurado",
        severity="MEDIO",
        description="logging.basicConfig en múltiples módulos",
        patterns=[
            r"logging\.basicConfig\s*\(",
        ],
        file_globs=["*.py"],
        fix_hint="Configurar logging una sola vez en el entry point"
    ),
    BugPattern(
        id="BS-MED-03",
        name="Datetime UTCNow Deprecado",
        severity="MEDIO",
        description="datetime.utcnow() está deprecado en Python 3.12+",
        patterns=[
            r"datetime\.utcnow\s*\(",
        ],
        file_globs=["*.py"],
        fix_hint="Usar datetime.now(timezone.utc)"
    ),
    BugPattern(
        id="BS-MED-04",
        name="Magic Numbers",
        severity="MEDIO",
        description="Números literales sin constantes con nombre descriptivo",
        patterns=[
            r"[^a-zA-Z_](3600|86400|1024|300|5000|8080|5432|6379)\b",
        ],
        file_globs=["*.py", "*.js", "*.ts", "*.go", "*.rs"],
        fix_hint="Extraer a constantes con nombres descriptivos"
    ),
    
    # === BAJOS ===
    BugPattern(
        id="BS-LOW-01",
        name="Falta de Type Hints",
        severity="BAJO",
        description="Funciones sin anotaciones de tipo",
        patterns=[
            r"^def\s+\w+\s*\([^)]*\)\s*:\s*$",  # def sin type hints
        ],
        file_globs=["*.py"],
        fix_hint="Agregar type hints y verificar con mypy"
    ),
    BugPattern(
        id="BS-LOW-02",
        name="TODO Sin Resolver",
        severity="BAJO",
        description="Comentarios TODO/FIXME que indican trabajo pendiente",
        patterns=[
            r"#\s*TODO",
            r"#\s*FIXME",
            r"#\s*HACK",
            r"#\s*XXX",
        ],
        file_globs=["*.py", "*.js", "*.ts", "*.go", "*.rs"],
        fix_hint="Resolver el TODO o convertir en issue tracked"
    ),
    BugPattern(
        id="BS-LOW-03",
        name="Comentarios Obsoletos",
        severity="BAJO",
        description="Comentarios que no reflejan el código actual",
        patterns=[
            r"#\s*.*\n.*#\s*DEPRECATED",
            r"#\s*.*\n.*#\s*OBSOLETE",
        ],
        file_globs=["*.py", "*.js", "*.ts", "*.go", "*.rs"],
        fix_hint="Actualizar o eliminar comentarios obsoletos"
    ),
]


def should_exclude(path: Path, exclude_dirs: List[str]) -> bool:
    """Verificar si un path debe ser excluido."""
    for part in path.parts:
        if part in exclude_dirs:
            return True
    return False


def find_files(project_dir: Path, globs: List[str], exclude_dirs: List[str]) -> List[Path]:
    """Encontrar archivos que coincidan con los globs."""
    files = []
    for glob in globs:
        for path in project_dir.rglob(glob):
            if not should_exclude(path, exclude_dirs):
                files.append(path)
    return files


def scan_file(file_path: Path, patterns: List[re.Pattern]) -> List[Tuple[int, str, re.Pattern]]:
    """Escanear un archivo buscando patrones de bugs."""
    matches = []
    try:
        with open(file_path, "r", encoding="utf-8", errors="ignore") as f:
            for line_num, line in enumerate(f, 1):
                for pattern in patterns:
                    if pattern.search(line):
                        matches.append((line_num, line.strip(), pattern))
    except Exception as e:
        print(f"  ⚠️  No se pudo leer {file_path}: {e}")
    return matches


def verify_project(project_dir: Path, strict: bool = False) -> Dict:
    """Verificar un proyecto completo."""
    results = {
        "total_files_scanned": 0,
        "bugs_found": [],
        "by_severity": {"CRÍTICO": 0, "ALTO": 0, "MEDIO": 0, "BAJO": 0},
        "clean": True,
    }
    
    print(f"\n🔍 Escaneando proyecto: {project_dir}")
    print(f"   Modo estricto: {'Sí' if strict else 'No'}")
    print("-" * 60)
    
    for bug_pattern in BUG_PATTERNS:
        # En modo no-strict, saltar severidades bajas
        if not strict and bug_pattern.severity == "BAJO":
            continue
            
        files = find_files(project_dir, bug_pattern.file_globs, bug_pattern.exclude_dirs)
        
        for file_path in files:
            results["total_files_scanned"] += 1
            matches = scan_file(file_path, bug_pattern.patterns)
            
            for line_num, line, pattern in matches:
                # Ignorar comentarios que documentan el patrón (ej: en este script)
                if "verify-zero-bugs" in line or "BugPattern" in line:
                    continue
                
                bug = {
                    "id": bug_pattern.id,
                    "name": bug_pattern.name,
                    "severity": bug_pattern.severity,
                    "file": str(file_path.relative_to(project_dir)),
                    "line": line_num,
                    "code": line[:80],  # Truncar para legibilidad
                    "fix_hint": bug_pattern.fix_hint,
                }
                results["bugs_found"].append(bug)
                results["by_severity"][bug_pattern.severity] += 1
                results["clean"] = False
    
    return results


def print_report(results: Dict):
    """Imprimir reporte de verificación."""
    print("\n" + "=" * 60)
    print("📋 REPORTE DE VERIFICACIÓN BUG SLAYER")
    print("=" * 60)
    
    if results["clean"]:
        print("\n✅ ESTADO: CERO BUGS ENCONTRADOS")
        print("   El proyecto está limpio de bugs conocidos.")
    else:
        print(f"\n❌ ESTADO: {len(results['bugs_found'])} BUGS ENCONTRADOS")
        
        # Agrupar por severidad
        for severity in ["CRÍTICO", "ALTO", "MEDIO", "BAJO"]:
            count = results["by_severity"][severity]
            if count == 0:
                continue
                
            icon = {"CRÍTICO": "🔴", "ALTO": "🟠", "MEDIO": "🟡", "BAJO": "🟢"}[severity]
            print(f"\n{icon} {severity}: {count} bugs")
            
            for bug in results["bugs_found"]:
                if bug["severity"] == severity:
                    print(f"   [{bug['id']}] {bug['file']}:{bug['line']}")
                    print(f"      {bug['name']}: {bug['code'][:60]}")
                    print(f"      💡 Fix: {bug['fix_hint']}")
    
    print(f"\n📊 Archivos escaneados: {results['total_files_scanned']}")
    print(f"🐛 Bugs totales: {len(results['bugs_found'])}")
    print("=" * 60)


def main():
    parser = argparse.ArgumentParser(
        description="Verificar que no quedan bugs conocidos en el proyecto"
    )
    parser.add_argument("project_dir", help="Directorio del proyecto a verificar")
    parser.add_argument(
        "--strict",
        action="store_true",
        help="Incluir severidad BAJO en la verificación"
    )
    parser.add_argument(
        "--json",
        action="store_true",
        help="Salida en formato JSON"
    )
    
    args = parser.parse_args()
    
    project_dir = Path(args.project_dir).resolve()
    if not project_dir.exists():
        print(f"❌ Error: El directorio {project_dir} no existe")
        sys.exit(1)
    
    results = verify_project(project_dir, strict=args.strict)
    
    if args.json:
        import json
        print(json.dumps(results, indent=2, ensure_ascii=False))
    else:
        print_report(results)
    
    sys.exit(0 if results["clean"] else 1)


if __name__ == "__main__":
    main()
