# Bug Taxonomy by Language

Checklist de bugs comunes organizados por lenguaje de programación.
Usar como guía durante la fase de auditoría para acelerar la detección.

---

## Python

### CRÍTICOS

#### PY-CRIT-01: Race Conditions en Inicialización
- **Patrón:** Variables globales chequeadas y seteadas en operaciones separadas
- **Señales:** `is_loading` boolean sin exclusión mutua, `check_and_reload()` llamado desde múltiples endpoints
- **Fix:** Reemplazar con `threading.Lock()` o `asyncio.Lock()`

#### PY-CRIT-02: SQLite Sin WAL Mode
- **Patrón:** `sqlite3.connect()` sin `PRAGMA journal_mode=WAL`
- **Señales:** `OperationalError: database is locked` en logs, múltiples servicios escribiendo a mismo `.db`
- **Fix:** Agregar `conn.execute("PRAGMA journal_mode=WAL")` en cada conexión

#### PY-CRIT-03: Bucles de Reintentos Infinitos
- **Patrón:** `while True: try...except: sleep(30)` sin límite de reintentos
- **Señales:** Bots, workers, o daemons que nunca terminan ante error persistente
- **Fix:** Backoff exponencial con máximo de reintentos

#### PY-CRIT-04: Null/None Dereference
- **Patrón:** Usar objeto que puede ser `None` sin verificación
- **Señales:** `self.llm.complete()`, `handlers[0]`, `config["key"]` sin guardas
- **Fix:** Early return con defaults seguros o `if obj is not None:`

#### PY-CRIT-05: Inyección de Código
- **Patrón:** `eval()`, `exec()`, `subprocess(shell=True)` con input de usuario
- **Señales:** Funciones que ejecutan strings dinámicos, `os.system(f"...")`
- **Fix:** Usar `ast.literal_eval()`, `subprocess.run([...])`, o validación estricta

#### PY-CRIT-06: Secretos Hardcodeados
- **Patrón:** API keys, tokens, passwords en código fuente
- **Señales:** Strings que parecen tokens, `api_key = "..."`, `password = "..."`
- **Fix:** Variables de entorno, vaults, o gestores de secretos

### ALTOS

#### PY-HIGH-01: Validación de Input Insuficiente
- **Patrón:** Aceptar input de usuario sin sanitización ni validación de tipo
- **Señales:** `request.json["field"]` sin `.get()`, `int(user_input)` sin try/except
- **Fix:** Validar con `pydantic`, `marshmallow`, o funciones de validación explícitas

#### PY-HIGH-02: Throttling/Rate Limiting Ausente
- **Patrón:** Requests HTTP sin delays ni backoff entre llamadas
- **Señales:** Scraper, integraciones con APIs externas, bots de mensajería
- **Fix:** `time.sleep(random.uniform(1,3))`, backoff exponencial, o librerías como `ratelimit`

#### PY-HIGH-03: Manejo de Errores Inconsistente
- **Patrón:** `except: pass` o `except Exception: pass` que traga errores silenciosamente
- **Señales:** Logs vacíos cuando debería haber errores, comportamiento "mágico"
- **Fix:** Loggear siempre el error, usar excepciones específicas

#### PY-HIGH-04: Caches Sin Límites
- **Patrón:** Diccionarios o SQLite usados como cache sin tamaño máximo
- **Señales:** Memory leaks, crecimiento de disco sin control
- **Fix:** `functools.lru_cache`, TTL, o política de evolución LRU

#### PY-HIGH-05: Operaciones No Atómicas
- **Patrón:** Leer archivo, modificar, escribir — sin atomicidad
- **Señales:** Corrupción de datos si el proceso muere mid-write
- **Fix:** Escribir a temp file + `os.replace()`, o usar transacciones de DB

#### PY-HIGH-06: Timeout Ausente en I/O
- **Patrón:** `requests.get()`, `socket.recv()`, operaciones de red sin timeout
- **Señales:** Requests que "cuelgan" indefinidamente
- **Fix:** Siempre especificar `timeout=` en requests, sockets, y DB connections

### MEDIOS

#### PY-MED-01: CORS Demasiado Permisivo
- **Patrón:** `allow_methods=["*"], allow_headers=["*"]`
- **Fix:** Especificar exactamente métodos y headers necesarios

#### PY-MED-02: Logging Mal Configurado
- **Patrón:** `logging.basicConfig()` en múltiples módulos
- **Fix:** Configurar logging una sola vez en el entry point

#### PY-MED-03: Uso de `datetime.utcnow()`
- **Patrón:** `datetime.utcnow()` en Python 3.12+ (deprecated)
- **Fix:** `datetime.now(timezone.utc)`

#### PY-MED-04: Magic Numbers/Strings
- **Patrón:** Números o strings literales esparcidos en el código
- **Fix:** Extraer a constantes con nombres descriptivos

#### PY-MED-05: Funciones Excesivamente Largas
- **Patrón:** Funciones de 100+ líneas, múltiples responsabilidades
- **Fix:** Refactorizar en funciones más pequeñas (SRP)

### BAJOS

#### PY-LOW-01: Falta de Type Hints
- **Patrón:** Funciones sin anotaciones de tipo
- **Fix:** Agregar type hints, usar `mypy` para verificar

#### PY-LOW-02: Comentarios Obsoletos
- **Patrón:** Comentarios que no reflejan el código actual
- **Fix:** Eliminar o actualizar comentarios

#### PY-LOW-03: Imports No Usados
- **Patrón:** `import` o `from` que no se utilizan
- **Fix:** `ruff check . --select F401` o `autoflake`

---

## JavaScript / TypeScript

### CRÍTICOS

#### JS-CRIT-01: XSS por innerHTML
- **Patrón:** `element.innerHTML = userInput`
- **Fix:** Usar `element.textContent` o sanitización con `DOMPurify`

#### JS-CRIT-02: Eval con Input de Usuario
- **Patrón:** `eval(userInput)`, `new Function(userInput)`
- **Fix:** JSON.parse con validación, o evitar eval completamente

#### JS-CRIT-03: Secretos en Cliente
- **Patrón:** API keys en código frontend, React env vars que empiezan sin `REACT_APP_`
- **Fix:** Variables de entorno solo en servidor, nunca en bundle cliente

#### JS-CRIT-04: Prototype Pollution
- **Patrón:** `obj[key] = value` donde `key` puede ser `__proto__` o `constructor`
- **Fix:** Validar keys, usar `Object.create(null)`, o librerías como `lodash` con `merge`

### ALTOS

#### JS-HIGH-01: Async/Await Sin Catch
- **Patrón:** `promise.then()` sin `.catch()`, `await` sin `try/catch`
- **Fix:** Siempre manejar rechazos, usar `.catch()` o `try/catch`

#### JS-HIGH-02: Comparación Débil
- **Patrón:** `==` en lugar de `===`, especialmente con `null`/`undefined`
- **Fix:** Usar `===` y `!==` siempre

#### JS-HIGH-03: Memory Leaks en Event Listeners
- **Patrón:** `addEventListener` sin `removeEventListener` correspondiente
- **Fix:** Limpiar listeners en `useEffect` return o `beforeDestroy`

#### JS-HIGH-04: SQL Injection en Queries
- **Patrón:** Concatenación de strings en queries SQL
- **Fix:** Parameterized queries con `?` placeholders

### MEDIOS

#### JS-MED-01: Uso de `var`
- **Patrón:** `var` en lugar de `let` o `const`
- **Fix:** Usar `const` por defecto, `let` solo cuando necesita reasignarse

#### JS-MED-02: Callback Hell
- **Patrón:** Anidación profunda de callbacks
- **Fix:** Promises, async/await, o librerías de control de flujo

#### JS-MED-03: Falta de Validación de Tipos en Runtime
- **Patrón:** Asumir que API devuelve siempre el formato esperado
- **Fix:** `zod`, `joi`, o validación manual de respuestas

### BAJOS

#### JS-LOW-01: Console.log en Producción
- **Patrón:** `console.log` de debug en código de producción
- **Fix:** Usar logger con niveles, o eliminar console.logs

#### JS-LOW-02: Nombres de Variables Poco Claros
- **Patrón:** `x`, `y`, `data`, `tmp` sin contexto
- **Fix:** Nombres descriptivos que revelen intención

---

## Go

### CRÍTICOS

#### GO-CRIT-01: Race Conditions en Goroutines
- **Patrón:** Acceso a shared state sin `sync.Mutex` o canales
- **Fix:** `sync.Mutex`, `sync.RWMutex`, o canales con buffer

#### GO-CRIT-02: Goroutines Sin Wait
- **Patrón:** `go func()` sin `sync.WaitGroup` o canal de sincronización
- **Fix:** Siempre sincronizar goroutines, nunca "fire and forget"

#### GO-CRIT-03: Panic Sin Recovery
- **Patrón:** `panic()` sin `defer recover()` en código de producción
- **Fix:** Usar `error` returns, solo `panic` en `init()` o casos irrecuperables

### ALTOS

#### GO-HIGH-01: Error Handling Incompleto
- **Patrón:** `_ = someFunc()` que ignora errores
- **Fix:** Siempre chequear `if err != nil`, nunca ignorar con `_`

#### GO-HIGH-02: Context Sin Timeout
- **Patrón:** `context.Background()` en requests HTTP o DB sin deadline
- **Fix:** `context.WithTimeout()`, `context.WithDeadline()`

#### GO-HIGH-03: SQL Injection
- **Patrón:** `fmt.Sprintf` en queries SQL
- **Fix:** Parameterized queries con `?` placeholders

### MEDIOS

#### GO-MED-01: Magic Numbers
- **Patrón:** Números literales sin constantes
- **Fix:** `const` con nombres descriptivos

#### GO-MED-02: Structs Sin Tags de JSON
- **Patrón:** Campos exportados sin `json:"field_name"`
- **Fix:** Agregar tags de serialización explícitas

### BAJOS

#### GO-LOW-01: Imports No Usados
- **Patrón:** `import` que no se utiliza
- **Fix:** `goimports` o `gofmt` automático

#### GO-LOW-02: Falta de Documentación en APIs Exportadas
- **Patrón:** Funciones/structs exportados sin comentario
- **Fix:** Comentarios que empiecen con nombre del símbolo

---

## Rust

### CRÍTICOS

#### RS-CRIT-01: Unsafe Code Sin Justificación
- **Patrón:** `unsafe` blocks sin documentación de invariants
- **Fix:** Minimizar `unsafe`, documentar con `// SAFETY:` comments

#### RS-CRIT-02: Panic en Código de Producción
- **Patrón:** `.unwrap()`, `.expect()` en código que maneja input externo
- **Fix:** `?` operator, `match`, o `if let` con manejo de errores

### ALTOS

#### RS-HIGH-01: Clone Excesivo
- **Patrón:** `.clone()` en bucles o código hot-path
- **Fix:** Usar referencias (`&T`), `Arc`, o `Rc` según ownership

#### RS-HIGH-02: Bloqueo de Async en Runtime
- **Patrón:** Código síncrono bloqueante dentro de `async` functions
- **Fix:** `tokio::task::spawn_blocking` para I/O síncrono

### MEDIOS

#### RS-MED-01: Warnings No Atendidos
- **Patrón:** `#![allow(warnings)]` o múltiples warnings de compilación
- **Fix:** Resolver warnings, no suprimirlos

#### RS-MED-02: Falta de Tests
- **Patrón:** Módulos sin `#[cfg(test)]` o tests vacíos
- **Fix:** Tests unitarios, de integración, y property-based con `proptest`

### BAJOS

#### RS-LOW-01: Nombres de Variables Poco Idiomáticos
- **Patrón:** No seguir convenciones de naming de Rust
- **Fix:** `snake_case` para variables/funciones, `PascalCase` para tipos

#### RS-LOW-02: Imports No Usados
- **Patrón:** `use` statements que no se utilizan
- **Fix:** `cargo fix` o `rustfmt`
